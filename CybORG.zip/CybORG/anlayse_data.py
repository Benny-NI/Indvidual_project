import numpy as np 
import json
import matplotlib.pyplot as plt
import os
import seaborn as sns
def get_entropy_of_actions(action_sums):
    action_entropy = -1*np.sum(np.multiply(action_sums/100,np.log((action_sums+1e-8)/100)), axis = 1 )
    print(action_entropy.shape)
    return(action_entropy)





def intalise_data_input(path_to_training_data):

        ordered_data_paths = get_old_data_file_names(path_to_training_data)
        if ordered_data_paths == []:
            return {}

        init_replay_buffer = {}

        for i, data in enumerate(ordered_data_paths):
            
            data_name = os.listdir(f'{path_to_training_data}/{data}')[0]
            path_to_data = f'{path_to_training_data}/{data}/{data_name}'
            data = json.load(open(path_to_data))
        
            for key, value in data.items():

                init_replay_buffer[str(((int(key))+i*12) - 1)] = value
                
        return(init_replay_buffer)

def get_old_data_file_names(path_to_training_data):
       
        listed_traing_data = os.listdir(path_to_training_data)
        listed_traing_data = [x for x in listed_traing_data if x != '.DS_Store']
        if listed_traing_data == []:
            return []
        
        oreded_data = list((sorted(listed_traing_data)))

        return (oreded_data)

def get_array_of_action_sums(data):
    red_action_sums = []
    blue_action_sums = []

    for key, episode in data.items():
        for t, step in episode.items():
            if t == '0':
                red_action_sum = np.array(step['red']['action'])
                blue_action_sum = np.array(step['blue']['action'])
            else:
                red_action_sum += np.array(step['red']['action'])
                blue_action_sum += np.array(step['blue']['action'])
        
        red_action_sums.append(red_action_sum)
        blue_action_sums.append(blue_action_sum)

    return np.array(red_action_sums), np.array(blue_action_sums)


def get_array_of_cumultive_rewards(data):
    red_cumulative_rewards = []
    blue_cumulative_rewards = []

    for key, episode in data.items():
        for t, step in episode.items():
            if t == '0':
                red_cumulative_reward = step['red']['reward']
                blue_cumulative_reward = step['blue']['reward']
            else:
                red_cumulative_reward += step['red']['reward']
                blue_cumulative_reward += step['blue']['reward']
        
        red_cumulative_rewards.append(red_cumulative_reward)
        blue_cumulative_rewards.append(blue_cumulative_reward)

    return np.array(red_cumulative_rewards), np.array(blue_cumulative_rewards)

def incervse_transform_rewards(values):
    # print(values)
    return(values*16.8)

def get_mean_reward_for_n_steps(data):
    red_cumulative_rewards = np.array([])
    blue_cumulative_rewards = []

    for key, episode in data.items():
        for t, step in episode.items():
            
            if t == '0':
                red_cumulative_reward = step['red']['reward']
                # blue_cumulative_reward = step['blue']['reward']
            else:
                red_cumulative_reward += step['red']['reward']
                # blue_cumulative_reward += step['blue']['reward']
        
        red_cumulative_rewards = np.append(red_cumulative_reward, red_cumulative_rewards)
        # blue_cumulative_rewards.append(blue_cumulative_reward)

    
    red_cumulative_rewards = incervse_transform_rewards(red_cumulative_rewards)
    blue_cumulative_rewards = red_cumulative_rewards*-1

    return(red_cumulative_rewards, blue_cumulative_rewards)

data = intalise_data_input('Data_nsb')
# red_action_sums, blue_action_sums = get_array_of_action_sums(data)
red_rewards, blue_rewards = get_array_of_cumultive_rewards(data)

blue_rewards = blue_rewards

x_vals = list(range(0, len(blue_rewards), 12))

blue_rewards_average_of_each_series = [blue_rewards[i:i+12].mean() for i in range(0, len(blue_rewards), 12)] 

blue_rewards_std = [blue_rewards[i:i+12].std()/(12**0.5) for i in range(0, len(blue_rewards), 12)]


sns.set_context('paper')


plt.figure(figsize=(8,5))
plt.errorbar(x = x_vals, y = blue_rewards_average_of_each_series, yerr=blue_rewards_std, fmt='.', ecolor='lightsteelblue',capsize=1)
plt.ylabel('Percentage of total reward received by the blue agent')
plt.xlabel('Traing Steps')
plt.tight_layout()
plt.show()



# # print(red_action_sums.shape)
# red_rewards_average_of_each_series = [red_rewards[i:i+12].mean() for i in range(0, len(red_rewards), 12)]


# blue_rewards_average_of_each_series = [blue_rewards[i:i+12].mean() for i in range(0, len(blue_rewards), 12)] 

# action_sum_x_vals = list(range(0, len(red_action_sums)))

# x_vals = list(range(0, len(blue_rewards), 12))

# red_entropy = get_entropy_of_actions(red_action_sums)
# blue_entropy = get_entropy_of_actions(blue_action_sums)


# plt.figure()

# plt.subplot(3,2,1)
# # plt.title('Red Action Sums')
# # plt.plot(action_sum_x_vals, red_action_sums)
# plt.subplot(3,2,2)
# plt.title('Red Rewards')
# plt.plot(x_vals, red_rewards_average_of_each_series)
# plt.subplot(3,2,3)
# plt.title('Blue Action Sums')
# plt.plot(action_sum_x_vals, blue_action_sums,)
# # plt.yscale('log')
# plt.subplot(3,2,4)
# plt.title('Blue Rewards')
# plt.plot(x_vals, blue_rewards_average_of_each_series)
# plt.subplot(3,2,5)
# plt.title('Red action entropy')
# plt.plot(action_sum_x_vals, red_entropy)
# plt.title('Blue action entropy')
# plt.subplot(3,2,6)
# plt.plot(action_sum_x_vals, blue_entropy)
# plt.show()



