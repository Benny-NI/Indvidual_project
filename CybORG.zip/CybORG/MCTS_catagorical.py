import os
import re
from time import sleep, time
import json
import copy
from sympy import li
import torch
import random
from pprint import pprint
import inspect
import cProfile
import pstats
import io
from pstats import SortKey

import numpy as np

from tqdm import tqdm
from concurrent.futures import ProcessPoolExecutor, as_completed 
from CybORG import CybORG
from CybORG.Agents import B_lineAgent, RedMeanderAgent
from CybORG.Simulator.Scenarios import FileReaderScenarioGenerator
# from CybORG.Agents.Wrappers.Cage2PZWrapper import Cage2PZWrapper
# from CybORG.Agents.Wrappers.NewWrapper import NewWrapper 
# from CybORG.Agents.Wrappers.SelfPlayWrapperv3 import SelfPlayWrapperv3
from CybORG.Agents.Wrappers import SelfPlayWrapperv3

from MCTS.fully_nambered_search import Search
from MCTS.MCTS_replay_buffer_refactorised import ReplayBuffer
from MCTS.MCTS_train_models import train_modelsv3
from MCTS.MCTS_intalization_and_loading import *
from MCTS.MCTS_value_wrangeling import soft_temp_max, sftm_categorical_to_value

reward_step = 0.005
reward_support_set = np.arange(0, 1 + reward_step, reward_step)

value_step = 1
value_support_set = np.arange(0, 100 + value_step, value_step)


def execute_training(red_dyn, red_rep, red_pred, blue_dyn, blue_rep, blue_pred):
    '''
    Execute the the collection of training data
    
    Parameters:
    -----------
    red_dyn: nn.Module
        The red dynamics model
    red_rep: nn.Module
        The red representation model
    red_pred: nn.Module
        The red prediction model
    blue_dyn: nn.Module
        The blue dynamics model
    blue_rep: nn.Module
        The blue representation model
    blue_pred: nn.Module
        The blue prediction model
        
    Returns:
    --------
    episode_storage: dict
        The episode storage dictionary
    
    '''
    max_steps = 100
    max_num_sims = 800
    num_episodes = 12
    episode_storage = {}

    with ProcessPoolExecutor(max_workers=num_episodes) as executor:
        futures = [executor.submit(run_simulation, max_num_sims, max_steps, red_dyn, red_rep, red_pred, blue_dyn, blue_rep, blue_pred) for _ in range(num_episodes)]
        
        for i, future in enumerate(as_completed(futures)):
            try:
                result = future.result()
                pprint(f'Episode {i+1}:')
                episode_storage[i+1] = result
            except Exception as exc:
                print(f'Episode {i+1} generated an exception: {exc}')
                
    return episode_storage

def get_data_generation_observation(latest_observation, latest_action, recet_observations, recent_actions):

    obs = torch.tensor(latest_observation, dtype=torch.float32).view(1, -1)
    act = torch.tensor(latest_action, dtype=torch.float32).view(1, -1)
    
    new_total_observations = torch.cat((recet_observations, obs), dim=0)
    new_total_actions = torch.cat((recent_actions, act), dim=0)
    
    input_from_env = obs
    
    
    return new_total_observations, new_total_actions, input_from_env

def take_max_steps_against_bline(max_num_sims, max_steps, red_dyn, red_rep, red_pred, blue_dyn, blue_rep, blue_pred):
    '''
    Create the max number of steps for the MCTS and return the episode storage dictionary
    
    Parameters:
    -----------
    max_num_sims: int
        The maximum number of simulations
    max_steps: int
        The maximum number of steps
    red_dyn: nn.Module
        The red dynamics model
    red_rep: nn.Module
        The red representation model
    red_pred: nn.Module
        The red prediction model
    blue_dyn: nn.Module
        The blue dynamics model
    blue_rep: nn.Module
        The blue representation model
    blue_pred: nn.Module
        The blue prediction model
        
    Returns:
    --------
    episode_storage: dict
        The episode storage dictionary
        
    '''
    with torch.no_grad():
        bline_agent = RedMeanderAgent()
        
        red_dyn.eval()
        red_rep.eval()
        red_pred.eval()
        blue_dyn.eval()
        blue_rep.eval()
        blue_pred.eval()
        
        env, red_hidden_state, blue_hidden_state, searcher, red_result, blue_result = setup_environment(red_dyn, red_rep, red_pred, blue_dyn, blue_rep, blue_pred)


        # red_result, blue_result = env.reset()
    
        red_latest_observation = copy.copy(red_result.observation)
        red_action_vector = env.red_int_to_vector(0)
        
        blue_latest_observation = copy.copy(blue_result.observation)
        blue_action_vector = env.blue_int_to_vector(0)
        

        

        red_observations = torch.zeros((5, len(red_latest_observation)), dtype=torch.float32)
        red_actions = torch.zeros(5, len(red_action_vector), dtype=torch.float32)

        blue_observations = torch.zeros((5, len(blue_latest_observation)), dtype=torch.float32)
        blue_actions = torch.zeros(5, len(blue_action_vector), dtype=torch.float32)
        
        
        
        for i in range(5):
            red_observations[i, :] = torch.tensor(red_latest_observation, dtype=torch.float32).view(1, -1)
            red_actions[i, :] = torch.tensor(red_action_vector, dtype=torch.float32).view(1, -1)
            
            blue_actions[i, :] = torch.tensor(blue_action_vector, dtype=torch.float32).view(1, -1)
            blue_observations[i, :] = torch.tensor(blue_latest_observation, dtype=torch.float32).view(1, -1)
        
        red_action_space = env.env.environment_controller.agent_interfaces[
                                    'Red'].action_space.get_action_space()
        
    
        red_raw_observation =  env.env.environment_controller.observation['Red'].data

        episode_storage = {i: {} for i in range(max_steps)}
        

        for i in tqdm(range(max_steps)):
        # for i in range(max_steps):
            
            episode_storage[i].setdefault('red', {})
            episode_storage[i].setdefault('blue', {})
            
        
            blue_observations, blue_actions, blue_input_from_env = get_data_generation_observation(blue_latest_observation, blue_action_vector, blue_observations, blue_actions)

            converted_b_l_o = [int(num) for num in list(blue_latest_observation)]

            episode_storage[i]['blue']['observation'] = tuple(converted_b_l_o)
            
            # print(blue_input_from_env)
        
            blue_input = blue_hidden_state(blue_input_from_env)

        
            mask = env.get_action_mask('Blue')

        
            blue_policy, blue_pred_value = searcher.SEB(max_num_sims, blue_input, 'b', mask)

            

            blue_masked_policy = screened_policy('Blue', env, blue_policy)
            
            blue_action_int = blue_masked_policy.sample().int().item()
            blue_action = env.blue_int_to_action(blue_action_int)


            _, _, _, _, _, _ = env.stepv2(agent='Blue', action=blue_action)
            
            blue_action_vector = env.blue_int_to_vector(blue_action_int)
            

            red_observations, red_actions, red_input_from_env = get_data_generation_observation(red_latest_observation, red_action_vector, red_observations, red_actions)


            converted_r_l_o = [int(num) for num in list(red_latest_observation)]
            
            episode_storage[i]['red']['observation'] = tuple(converted_r_l_o)

        

            red_input = red_hidden_state(red_input_from_env)
            
            _, red_pred_value = red_pred(red_input)

            red_pred_value = soft_temp_max(red_pred_value)
            red_pred_value = sftm_categorical_to_value(red_pred_value, value_support_set)
        

            red_next_action = bline_agent.get_action(red_raw_observation, red_action_space)
            red_latest_observation, blue_latest_observation, red_raw_observation, _, red_reward, blue_reward = env.stepv2(agent='Red', action=red_next_action)
        

            red_action_int = env.red_action_to_int(red_next_action)

            red_action_vector = env.red_int_to_vector(red_action_int)
            
            # print(red_reward)

     

            episode_storage[i]['blue']['policy'] = tuple(blue_masked_policy.probs.view(-1).tolist())
            episode_storage[i]['blue']['action'] = tuple(blue_action_vector)
            episode_storage[i]['blue']['reward'] = blue_reward
            episode_storage[i]['blue']['value'] = blue_pred_value
            
            episode_storage[i]['red']['policy'] = tuple(red_action_vector)
            episode_storage[i]['red']['action'] = tuple(red_action_vector)
            episode_storage[i]['red']['reward'] = red_reward
            episode_storage[i]['red']['value'] = red_pred_value

            # print(f'Red action: {red_next_action}')
            # print(f'Red reward: {red_reward}')
            # print(f'Blue_action: {blue_action}')
            # print(f'Blue_observation: {blue_latest_observation}')
            # print(f'Red_observation: {red_latest_observation}')


            # print(tuple(blue_policy.probs.view(-1).tolist()))
            # print(tuple(blue_action_vector))
            # print(blue_reward)
            # print(blue_pred_value.item())


            
    return episode_storage



def take_max_steps_selfplay(max_num_sims, max_steps, red_dyn, red_rep, red_pred, blue_dyn, blue_rep, blue_pred):
    '''
    Create the max number of steps for the MCTS and return the episode storage dictionary
    
    Parameters:
    -----------
    max_num_sims: int
        The maximum number of simulations
    max_steps: int
        The maximum number of steps
    red_dyn: nn.Module
        The red dynamics model
    red_rep: nn.Module
        The red representation model
    red_pred: nn.Module
        The red prediction model
    blue_dyn: nn.Module
        The blue dynamics model
    blue_rep: nn.Module
        The blue representation model
    blue_pred: nn.Module
        The blue prediction model
        
    Returns:
    --------
    episode_storage: dict
        The episode storage dictionary
        
    '''
    with torch.no_grad():
        # bline_agent = RedMeanderAgent()
        
        red_dyn.eval()
        red_rep.eval()
        red_pred.eval()
        blue_dyn.eval()
        blue_rep.eval()
        blue_pred.eval()
        
        env, red_hidden_state, blue_hidden_state, searcher, red_result, blue_result = setup_environment(red_dyn, red_rep, red_pred, blue_dyn, blue_rep, blue_pred)


        # red_result, blue_result = env.reset()
    
        red_latest_observation = copy.copy(red_result.observation)
        red_action_vector = env.red_int_to_vector(0)
        
        blue_latest_observation = copy.copy(blue_result.observation)
        blue_action_vector = env.blue_int_to_vector(0)
        

        

        red_observations = torch.zeros((5, len(red_latest_observation)), dtype=torch.float32)
        red_actions = torch.zeros(5, len(red_action_vector), dtype=torch.float32)

        blue_observations = torch.zeros((5, len(blue_latest_observation)), dtype=torch.float32)
        blue_actions = torch.zeros(5, len(blue_action_vector), dtype=torch.float32)
        
        
        
        for i in range(5):
            red_observations[i, :] = torch.tensor(red_latest_observation, dtype=torch.float32).view(1, -1)
            red_actions[i, :] = torch.tensor(red_action_vector, dtype=torch.float32).view(1, -1)
            
            blue_actions[i, :] = torch.tensor(blue_action_vector, dtype=torch.float32).view(1, -1)
            blue_observations[i, :] = torch.tensor(blue_latest_observation, dtype=torch.float32).view(1, -1)
        
        # red_action_space = env.env.environment_controller.agent_interfaces[
        #                             'Red'].action_space.get_action_space()
        
    
        # red_raw_observation =  env.env.environment_controller.observation['Red'].data

        episode_storage = {i: {} for i in range(max_steps)}
        

        for i in tqdm(range(max_steps)):
        # for i in range(max_steps):
            
            episode_storage[i].setdefault('red', {})
            episode_storage[i].setdefault('blue', {})
            
        
            blue_observations, blue_actions, blue_input_from_env = get_data_generation_observation(blue_latest_observation, blue_action_vector, blue_observations, blue_actions)

            converted_b_l_o = [int(num) for num in list(blue_latest_observation)]

            episode_storage[i]['blue']['observation'] = tuple(converted_b_l_o)
            
            # print(blue_input_from_env)
        
            blue_input = blue_hidden_state(blue_input_from_env)

        
            blue_mask = env.get_action_mask('Blue')

        
            blue_policy, blue_pred_value = searcher.SEB(max_num_sims, blue_input, 'b', blue_mask)

            # print(blue_pred_value)
            # print(blue_policy)

            blue_masked_policy = screened_policy('Blue', env, blue_policy)
            
            blue_action_int = blue_masked_policy.sample().int().item()
            blue_action = env.blue_int_to_action(blue_action_int)


            _, _, _, _, _, _ = env.stepv2(agent='Blue', action=blue_action)
            
            blue_action_vector = env.blue_int_to_vector(blue_action_int)
            

            red_observations, red_actions, red_input_from_env = get_data_generation_observation(red_latest_observation, red_action_vector, red_observations, red_actions)


            converted_r_l_o = [int(num) for num in list(red_latest_observation)]
            
            episode_storage[i]['red']['observation'] = tuple(converted_r_l_o)

        

            red_input = red_hidden_state(red_input_from_env)
            
            red_mask = env.get_action_mask('Red')

        
            red_policy, red_pred_value = searcher.SEB(max_num_sims, red_input, 'r', red_mask)


            

            red_masked_policy = screened_policy('Red', env, red_policy)
            
            

            red_action_int = red_masked_policy.sample().int().item()
            red_action = env.red_int_to_action(red_action_int)


            red_latest_observation, blue_latest_observation, _, _, red_reward, blue_reward = env.stepv2(agent='Red', action=red_action)
        


            red_action_vector = env.red_int_to_vector(red_action_int)
            
            # print(red_reward)

     

            episode_storage[i]['blue']['policy'] = tuple(blue_masked_policy.probs.view(-1).tolist())
            episode_storage[i]['blue']['action'] = tuple(blue_action_vector)
            episode_storage[i]['blue']['reward'] = blue_reward
            episode_storage[i]['blue']['value'] = blue_pred_value
            
            episode_storage[i]['red']['policy'] = tuple(red_action_vector)
            episode_storage[i]['red']['action'] = tuple(red_action_vector)
            episode_storage[i]['red']['reward'] = red_reward
            episode_storage[i]['red']['value'] = red_pred_value

            # print(f'Red action: {red_next_action}')
            # print(f'Red reward: {red_reward}')
            # print(f'Blue_action: {blue_action}')
            # print(f'Blue_observation: {blue_latest_observation}')
            # print(f'Red_observation: {red_latest_observation}')


            # print(tuple(blue_policy.probs.view(-1).tolist()))
            # print(tuple(blue_action_vector))
            # print(blue_reward)
            # print(blue_pred_value.item())


            
    return episode_storage

def setup_environment(red_dynamics, red_hidden_state, red_prediction,
                      blue_dynamics, blue_hidden_state, blue_prediction):
    '''
    Setup the environment
    
    Parameters:
    -----------
    red_dynamics: nn.Module
        The red dynamics model
    red_hidden_state: nn.Module
        The red hidden state model
    red_prediction: nn.Module
        The red prediction model
    blue_dynamics: nn.Module
        The blue dynamics model
    blue_hidden_state: nn.Module
        The blue hidden state model
    blue_prediction: nn.Module
        The blue prediction model
    
    Returns:
    --------
    env: CybORG
        The CybORG environment
    red_hidden_state: nn.Module
        The red hidden state model
    blue_hidden_state: nn.Module
        The blue hidden state model
    searcher: Search
        The searcher object
    
        '''
    
    
    
    path = str(inspect.getfile(CybORG))
    path = path[:-7] + '/Simulator/Scenarios/scenario_files/Scenario1b.yaml'
    sg = FileReaderScenarioGenerator(path)

    cyborg = CybORG(sg, 'sim')
    env = SelfPlayWrapperv3(env=cyborg)
    
    red_reset_result, blue_reset_result = env.reset()

    red_action_space = red_reset_result.action_space
    blue_action_space = blue_reset_result.action_space
   
    searcher = Search(red_action_space, red_prediction, red_dynamics,
                      blue_action_space, blue_prediction, blue_dynamics)

    return env, red_hidden_state, blue_hidden_state, searcher, red_reset_result, blue_reset_result

def run_simulation(max_num_sims, max_steps, red_dyn, red_rep, red_pred, blue_dyn, blue_rep, blue_pred):
    '''
    Run the simulation for the MCTS (needed for the parallelization)
    
    Parameters:
    -----------
    max_num_sims: int
        The maximum number of simulations
    max_steps: int
        The maximum number of steps
    red_dyn: nn.Module
        The red dynamics model
    red_rep: nn.Module
        The red representation model
    red_pred: nn.Module
        The red prediction model
    blue_dyn: nn.Module
        The blue dynamics model
    blue_rep: nn.Module
        The blue representation model
    blue_pred: nn.Module
        The blue prediction model
        
    Returns:
    --------
    take_max_steps: dict
        The episode storage dictionary
        
    '''
    return take_max_steps_selfplay(max_num_sims, max_steps, red_dyn, red_rep, red_pred, blue_dyn, blue_rep, blue_pred)

def inner_loop_int8():
    path_to_model_storage = 'Models_puct2_self_play_adam_PER'
    path_to_training_data = 'Data_puct2_self_play_adam_PER'

    
    red_dynamics, red_prediction, red_hidden_state, blue_dynamics, blue_prediction, blue_hidden_state = get_latest_model_versions(path_to_model_storage)

    replay_buffer = ReplayBuffer(path_to_training_data = path_to_training_data, 
                                 blue_hidden_state = blue_hidden_state,
                                 blue_prediction = blue_prediction,
                                 red_hidden_state = red_hidden_state,
                                 red_prediction = red_prediction)
    
    print('Getting data')
    
    data, weights = replay_buffer.get_batch(batch_size=1200)

    if data is not None:
        print('Training models')
       
        red_dynamics, red_prediction, red_hidden_state, blue_dynamics, blue_prediction, blue_hidden_state = train_modelsv3(red_dynamics, red_prediction, red_hidden_state, blue_dynamics, blue_prediction, blue_hidden_state, data, weights)
        replay_buffer.update_models =  blue_hidden_state, blue_prediction, red_hidden_state, red_prediction
        save_models(red_dynamics, red_prediction, red_hidden_state, blue_dynamics, blue_prediction, blue_hidden_state, path_to_model_storage)

    new_training_data = execute_training(red_dynamics, red_hidden_state, red_prediction, blue_dynamics, blue_hidden_state, blue_prediction)
    
    new_data_path = f'{path_to_training_data}/{time()}'
    os.makedirs(new_data_path)
    
    # compete_against_agent(red_dynamics, red_hidden_state, red_prediction, blue_dynamics, blue_hidden_state, blue_prediction, 30, 30)
    replay_buffer.fifo_update(new_training_data)
    
    
    with open(f'{new_data_path}/training_data_{time()}.json', 'w') as fp:
        json.dump(new_training_data, fp)


    # replay_buffer.fifo_update(new_training_data)
    
    print(f'Training complete, new data saved at {new_data_path}')
    print(f'Training complete, new models saved at {path_to_model_storage}')

def just_produce_data():
    
    '''
    The inner loop of the automatic training process and subsquent logging
    
    '''
    path_to_model_storage = 'Models_puct2_self_play_adam_PER'

    
    red_dynamics, red_prediction, red_hidden_state, blue_dynamics, blue_prediction, blue_hidden_state = get_latest_model_versions(path_to_model_storage)
  
    
        # save_losees('log_of_losses.json', log_of_losses)
   
    max_steps = 100
    max_num_sims = 800
    epsiode_dict = take_max_steps_selfplay(max_num_sims, max_steps, red_dynamics, red_hidden_state, red_prediction, blue_dynamics, blue_hidden_state, blue_prediction)
    
def screened_policy(agent: str, env: SelfPlayWrapperv3, policy: np.array):
    # new_polciy = torch.zeros((1, len(policy.probs)), dtype=torch.float32)
    
    

    action_mask = env.get_action_mask(agent)

    num_legal_actions = sum(action_mask.values())
    # num_illiegal_action = len(action_mask.values()) - num_legal_actions
    legal_problity_mass = sum([prob if action_mask[i]== 1 else 0 for i, prob in  enumerate(policy)])

    illiegal_problity_mass = 1 - legal_problity_mass

    legal_problity_mass = sum([prob if action_mask[i]== 1 else 0 for i, prob in  enumerate(policy)])

    if legal_problity_mass == 0:
        num_legal_actions = sum(action_mask.values())
        new_policy =  [1/num_legal_actions if action_mask[i]== 1 else 0 for i, _ in enumerate(policy)]

    elif  (illiegal_problity_mass/num_legal_actions) < 0.00005:
       
        new_policy = [prob for i, prob in enumerate(policy)]
        
        
    else:
        addative_factor = illiegal_problity_mass/num_legal_actions
        new_policy = [prob + addative_factor if action_mask[i]== 1 else 0 for i, prob in enumerate(policy)]

    new_policy = (torch.tensor(new_policy)).view(1,-1)
   
    new_policy = torch.distributions.Categorical(probs = new_policy)

    return(new_policy)
 
def e_greedy_policy(policy: np.array):
    '''
    Create an epsilon greedy policy
    
    Parameters:
    -----------
    policy: np.array
        The policy
        
    Returns:
    --------
    new_policy: np.array
        The new policy
        
    '''
    epsilon = 0.2
    num_actions = len(policy)
    action = np.random.choice([0, 1], p=[1-epsilon, epsilon])
    
    if action == 0:
        new_policy = policy
    else:
        new_policy = np.array([1/num_actions]*num_actions)
        
    return new_policy

def just_make_preds():

    path_to_model_storage = 'Models_puct2_self_play_adam_PER'

    
    _, red_prediction, _, _, blue_prediction, _ = get_latest_model_versions(path_to_model_storage)
  
    
        # save_losees('log_of_losses.json', log_of_losses)
   
    max_steps = 250
    max_num_sims = 100
    red_input = torch.randn(1, 64)
    blue_input = torch.randn(1, 64)

    for i in tqdm(range(120000)):
        red_policy, red_value = red_prediction(red_input)
        blue_policy, blue_value = blue_prediction(blue_input)

def check_training():
    path_to_model_storage = 'Models_puct2_self_play_adam_PER'
    path_to_training_data = 'Data_puct2_self_play_adam_PER'

    
    red_dynamics, red_prediction, red_hidden_state, blue_dynamics, blue_prediction, blue_hidden_state = get_latest_model_versions(path_to_model_storage)

    replay_buffer = ReplayBuffer(path_to_training_data = path_to_training_data, 
                                 blue_hidden_state = blue_hidden_state,
                                 blue_prediction = blue_prediction,
                                 red_hidden_state = red_hidden_state,
                                 red_prediction = red_prediction)
    
    print('Getting data')
    
    data, weights = replay_buffer.get_uniform_random_sample(batch_size=1200)

    if data is not None:
        print('Training models')
       
        red_dynamics, red_prediction, red_hidden_state, blue_dynamics, blue_prediction, blue_hidden_state = train_modelsv3(red_dynamics, red_prediction, red_hidden_state, blue_dynamics, blue_prediction, blue_hidden_state, data, weights)
        # replay_buffer.update_models =  blue_hidden_state, blue_prediction, red_hidden_state, red_prediction
        # save_models(red_dynamics, red_prediction, red_hidden_state, blue_dynamics, blue_prediction, blue_hidden_state, path_to_model_storage)


    
if __name__ == '__main__':
   

    while True:
        inner_loop_int8()

   

        





