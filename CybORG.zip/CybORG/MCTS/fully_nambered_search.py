from copy import copy, deepcopy
from email import policy
import pprint
from time import sleep
from torch import nn
import numpy as np
import torch
import cProfile
import pstats
from numba import jit, njit
from MCTS.MCTS_value_wrangeling import sftm_categorical_to_value, soft_temp_max



class Search:
    ''' A class to implement the search algorithm for the MCTS using duel networks for the agents
    '''
    def __init__(self, red_action_space: list, red_prediction_net: nn.Module,
                 red_dynamics_net: nn.Module, blue_action_space: list,
                 blue_prediction_net: nn.Module, blue_dynamics_net: nn.Module):
        '''
        Intilise the search class with the required parameters
        
        Parameters:
        -----------
        red_action_space: List
            The action space for the red agent
        red_prediction_net: nn.Module
            The prediction network for the red agent
        red_dynamics_net: nn.Module
            The dynamics network for the red agent
        blue_action_space: nn.Module
            The action space for the blue agent
        blue_prediction_net: nn.Module
            The prediction network for the blue agent
        blue_dynamics_net: nn.Module
            The dynamics network for the blue agent
            
        Returns:
        --------
        None
        
        '''
        self.red_action_space = red_action_space
        self.red_prediction_net = red_prediction_net
        self.red_dynamics_net = red_dynamics_net
        self.blue_action_space = blue_action_space
        self.blue_prediction_net = blue_prediction_net
        self.blue_dynamics_net = blue_dynamics_net
        self.blue_action_space_int = np.arange(len(blue_action_space))
        self.red_action_space_int = np.arange(len(red_action_space))
        self.count_dict = {}
        self.value_sum_dict = {}
        self.state_transition_dict = {}
        self.policy_dict = {}
        self.red_max_value = 0
        self.blue_max_value = 0
        self.red_min_value = 0
        self.blue_min_value = 0

       
        self.h_value_sum_dict = 0
        self.c1 = 2
        self.c2 = 19652
        self.discount_factor = 0.99
        self.device = ('cpu')

        self.max_depth = 20

        self.reward_step = 0.005
        self.reward_support_set = np.arange(0, 1 + self.reward_step, self.reward_step)


        self.value_step = 1
        self.value_support_set = np.arange(0, 100 + self.value_step, self.value_step)


        
    
    @staticmethod
    def tensor_to_tuple(tensor: torch.tensor):
        '''
        Convert a tensor to a tuple
        
        Parameters:
        -----------
        tensor: torch.tensor
            The tensor to convert to a tuple
            
        Returns:
        --------
        tuple
            The tensor converted to a tuple
        
        '''
     
        return tuple(tensor.flatten().tolist())


    
    
    # def update_min_max_values(self, values: np.array, turn: str):
    #     if turn == 'r':
    #         self.red_max_value = max(np.max(values), self.red_max_value)
    #         self.red_min_value = min(np.min(values), self.red_min_value)
    #         return self.red_min_value, self.red_max_value
    #     else:
    #         self.blue_max_value = max(np.max(values), self.blue_max_value)
    #         self.blue_min_value = min(np.min(values), self.blue_min_value)
    #         return self.blue_min_value, self.blue_max_value

    
    def update_min_max_values(self, values: np.array, turn: str):
        # Calculate min and max only once
        current_max = np.max(values)
        current_min = np.min(values)
        
        if turn == 'r':
            # Update red min/max values in place
            self.red_max_value = max(current_max, self.red_max_value)
            self.red_min_value = min(current_min, self.red_min_value)
            return self.red_min_value, self.red_max_value
        else:
            # Update blue min/max values in place
            self.blue_max_value = max(current_max, self.blue_max_value)
            self.blue_min_value = min(current_min, self.blue_min_value)
            return self.blue_min_value, self.blue_max_value


        
    
    def transform_values(self, values: np.array, turn: str):
        '''
        Vectorized transformation of an array of values to the range [0, 1]
        
        Parameters:
        -----------
        values: np.array
            The array of values to transform
        turn: str
            The turn of the agent
            
        Returns:
        --------
        np.array
            The transformed array of values
        '''
        if turn == 'r':
            min_value = self.red_min_value
            max_value = self.red_max_value
        else:
            min_value = self.blue_min_value
            max_value = self.blue_max_value
        
        return min_value, max_value
    
    @staticmethod
    @njit
    def tv(values, min_value, max_value):
        # Prevent division by zero
        if max_value == min_value:
            return np.zeros_like(values)
        
        # Vectorized transformation
        return (values - min_value) / (max_value - min_value)
        

         
    def inverse_transform_value(self, value: float, turn:str):
        ''' Inverse transform the value of the state (used for debugging)
        
        Parameters:
        -----------
        value: float
            The value to inverse transform
        turn: str
            The turn of the agent
            
        Returns:
        --------
        float
            The inverse transformed value
        
        '''
        if turn == 'r':
            return value * (self.red_max_value - self.red_min_value) + self.red_min_value
        else:
            return value * (self.blue_max_value - self.blue_min_value) + self.blue_min_value

    
    def action_ohe(self, action, action_space):
        ''' One-hot encodes an action
        
        Parameters:
        -----------
        action: str
            The action to one-hot encode
        action_space: List
            The action space for the agent
            
        Returns:
        --------
        torch.tensor
            The one-hot encoded action
            
        '''
        action_int = action if isinstance(action, int) else action_space.index(action)
        ohe = torch.zeros((1, len(action_space)), dtype=torch.float32)
        ohe[0, action_int] = 1.0
        return ohe

    
    def red_dynamics(self, state, action):
        ''' Get the dynamics for the red agent
        
        Parameters:
        -----------
        state: torch.tensor
            The hidden state representation of the environment
        action: str
            The action to take
            
        Returns:
        --------
        torch.tensor
            The reward for taking the action given the state and the new state representation
            
            '''
  
        action_ohe = self.action_ohe(action, self.red_action_space)
        input_tensor = torch.cat((state, action_ohe), dim=1)
        state, reward = self.red_dynamics_net(input_tensor)
        reward = soft_temp_max(reward)
        reward = sftm_categorical_to_value(reward, self.reward_support_set)
        return state, reward
    
    
    def red_prediction(self, state):
        ''' get the prediction for the red agent
        
        Parameters:
        -----------
        state: torch.tensor
            The hidden state representation of the environment
            
        Returns:
        --------
        torch.tensor
            The prediction value for the red agent's expected returns from the state
            
        '''
    
        p,v = self.red_prediction_net(state)
        p, v = soft_temp_max(p), soft_temp_max(v)
        v = sftm_categorical_to_value(v, self.value_support_set)
        return p, v

    
    def blue_dynamics(self, state, action):
        ''' Get the dynamics for the blue agent
        
        Parameters:
        -----------
        state: torch.tensor
            The hidden state representation of the environment
        action: str
            The action to take
            
        Returns:
        --------
        torch.tensor
            The dynamics of the blue agent
            
        '''
        action_ohe = self.action_ohe(action, self.blue_action_space)
        input_tensor = torch.cat((state, action_ohe), dim=1)
        state, reward = self.blue_dynamics_net(input_tensor)
        reward = soft_temp_max(reward)
        reward = sftm_categorical_to_value(reward, self.reward_support_set)
        return state, reward

    
    def blue_prediction(self, state):
        ''' Get the prediction for the blue agent
        
        Parameters:
        -----------
        state: torch.tensor
            The state of the environment
            
        Returns:
        --------
        torch.tensor
            The prediction for the blue agent
            
        '''
        # state.to(self.device)

        p,v = self.blue_prediction_net(state)
        p, v = soft_temp_max(p), soft_temp_max(v)
        v = sftm_categorical_to_value(v, self.value_support_set)
        return p, v


    @jit    
    def action_to_int(self, action, action_space):
        ''' Convert an action to its corresponding integer
        
        Parameters:
        -----------
        action: str
            The action to convert
        action_space: List
            The action space for the agent
            
        Returns:
        --------
        int
            The integer corresponding to the action
        
        '''
        return action_space.index(action)

    @jit
    def int_to_action(self, number, action_space):
        ''' Convert an integer to its corresponding action
        
        Parameters:
        -----------
        number: int
            The integer to convert
        action_space: List
            The action space for the agent
        
        Returns:
        --------
        str
            The action corresponding to the integer
        
        '''
        return action_space[number]

   
    @staticmethod
    @njit
    def compute_ucb_values(mean_values, p_sa, action_visits, c1):
        # Convert state tensor to tuple for dictionary access
        

        # Convert the action space to a list of indices
        

        sum_of_state_visits = sum(action_visits)

        




        # Retrieve policy probabilities for all actions
        
        # p_sa = 1
   

        
        # Get the state visits count
       

        # Get action visit counts

        

        # Compute the exploration term for all actions
        exploration_term = np.sqrt(sum_of_state_visits) / (1 + action_visits)

        # Transform mean values for all actions


        

        
        

        
       
        # mean_values = np.array([self.transform_value(mean_value[state_tuple][turn].get(action), turn) for action in action_indices])

        

        # Transform all values at once
       

        # Compute UCB values for all actions

        ucb_values = mean_values + p_sa * exploration_term * (c1)
        

        
        return ucb_values
    

    @staticmethod
    @njit
    def compute_uct_values(mean_values, p_sa, action_visits, c1):
        # Convert state tensor to tuple for dictionary access
        

        # Convert the action space to a list of indices
        

        sum_of_state_visits = sum(action_visits)

        




        # Retrieve policy probabilities for all actions
        
        # p_sa = 1
   

        
        # Get the state visits count
       

        # Get action visit counts

        

        # Compute the exploration term for all actions
        exploration_term = np.sqrt(np.log(sum_of_state_visits)/ (1e-5 + action_visits))

        # Transform mean values for all actions


        

        
        

        
       
        # mean_values = np.array([self.transform_value(mean_value[state_tuple][turn].get(action), turn) for action in action_indices])

        

        # Transform all values at once
       

        # Compute UCB values for all actions

        ucb_values = mean_values +  exploration_term * (c1)
        

        
        return ucb_values
    
    @staticmethod
    def get_one_ups(state_tuple, mean_value, policy, visit_count, turn):
        mean_values = mean_value[state_tuple][turn]
        p_sa_one_up = policy[state_tuple][turn]
        action_visits_one_up = visit_count[state_tuple][turn]
        return mean_values, p_sa_one_up, action_visits_one_up

    def arg_max_ucb_parallel(self, state, action_space_int, mean_value, policy, visit_count, turn):
        state_tuple = self.tensor_to_tuple(state)

        mean_values, p_sa_one_up, action_visits_one_up = self.get_one_ups(state_tuple, mean_value, policy, visit_count, turn)

        min_value, max_value = self.update_min_max_values(mean_values, turn)
        
        mean_values = self.tv(mean_values, min_value, max_value)
      

        ucb_values = self.compute_ucb_values(mean_values, p_sa_one_up, action_visits_one_up, self.c1)
        
        return(self.get_highest_ucb_action(ucb_values))
    
    @staticmethod
    @njit
    def get_highest_ucb_action(ucb_values):
         # Find the indices of the maximum UCB value
        max_ucb = np.max(ucb_values)
        max_indices = np.flatnonzero(ucb_values == max_ucb)
        
        # If multiple indices have the max value, choose one randomly
        if len(max_indices) > 1:
            best_action_index = np.random.choice(max_indices)
        else:
            best_action_index = max_indices[0]
        
        return int(best_action_index)

    
    def write_policy(self, state, policy, policy_dict, turn, policy_mask = None, is_dirichlet=False):
        ''' Write the policy for a given state
        
        Parameters:
        -----------
        state: torch.tensor
            The state of the environment
        policy: torch.tensor
            The policy for the state
        policy_dict: Dict
            The policy dictionary
        turn: str
            The turn of the agent
            
        Returns:
        --------
        None
        
        '''

        state_tuple = self.tensor_to_tuple(state)

        flat_policy = policy.flatten().tolist()
        flat_np_policy = np.array(flat_policy)
       
    
        policy_dict[state_tuple][turn] = flat_np_policy

    def update_statsv4(self, states, actions_ints, rewards, value, count_dict, value_sum_dict, turn, leaf_turn):
        ''' Update the statistics for the state-action pairs
        
        Parameters:
        -----------
        states: List
            The states visited
        actions_ints: List
            The actions taken
        rewards: List
            The rewards received
        value: float
            The value of the leaf node
        count_dict: Dict
            The count dictionary
        value_sum_dict: Dict
            The value sum dictionary
        turn: str
            The current turn ('r' or 'b')
        leaf_turn: str
            The turn of the leaf node
            
        Returns:
        --------
        None
        '''

        if (turn != leaf_turn):
            value = (value - rewards[-1]) / self.discount_factor
            # value = torch.tensor(value).view(1, -1)
        else:
            value
 
        # Precompute the discount factor once to avoid recalculating it
        discount_factor = self.discount_factor
        if not isinstance(rewards, np.ndarray):
           
    
            rewards = np.array(rewards)
        
        for i, (state, action) in enumerate(zip(states, actions_ints)):
            state_tuple = self.tensor_to_tuple(state)

            # Update the count dictionary
            action_count = count_dict[state_tuple][turn][action] + 1
            count_dict[state_tuple][turn][action] = action_count 

            # Calculate the discounted reward
          
            discounted_reward = self.get_discounted_rewards(rewards[i:], value, discount_factor)

            # Update the value sum dictionary using a running mean
            vsd = value_sum_dict[state_tuple][turn][action]
            value_sum_dict[state_tuple][turn][action] = vsd + (discounted_reward - vsd) / action_count

       
          
          
    
    @staticmethod
    @njit
    def get_discounted_rewards(rewards, leaf_value, discount_factor=0.99):
        ''' Get the discounted rewards
        
        Parameters:
        -----------
        rewards: List or numpy array
            The rewards received
        leaf_value: float
            The value of the leaf node
        discount_factor: float
            The discount factor
        
        Returns:
        --------
        float
            The discounted rewards
        
        '''
        
        # Ensure rewards is a numpy array
       
        
        # Reverse rewards and compute discounted sum
        rewards = rewards[::-1]
        discounts = np.power(discount_factor, np.arange(len(rewards), dtype=np.float32))
        
        discounted_rewards = np.sum(rewards * discounts) + (discount_factor ** len(rewards)) * leaf_value
        
        return discounted_rewards

    
    def initalise_given_a_state(self, state, count_dict ,policy_dict, value_sum_dict, policy_for_leaf, turn):
        ''' Initialise the state
        
        Parameters:
        -----------
        state: torch.tensor
            The state of the environment
        count_dict: Dict
            The count dictionary
        policy_dict: Dict
            The policy dictionary
        value_sum_dict: Dict
            The value sum dictionary
        policy_for_leaf: torch.tensor
            The policy for the leaf node
        turn: str
            The turn of the agent
            
        Returns:
        --------
        None
        
        '''
        
        state_tuple = self.tensor_to_tuple(state)

        count_dict.setdefault(state_tuple, {'r': np.zeros(len(self.red_action_space_int)), 'b': np.zeros(len(self.blue_action_space_int))})
        policy_dict.setdefault(state_tuple, {'r': np.zeros(len(self.red_action_space_int)), 'b': np.zeros(len(self.blue_action_space_int))})
        value_sum_dict.setdefault(state_tuple, {'r': np.zeros(len(self.red_action_space_int)), 'b': np.zeros(len(self.blue_action_space_int))})
        # reward_dict.setdefault(state_tuple, {'r': {}, 'b': {}})
        self.write_policy(state, policy_for_leaf, policy_dict, turn, is_dirichlet=False)

    
    def check_leafv2(self, state, action, count_dict, action_space, turn):
        ''' Check if the state action pair is a leaf node
        
        Parameters:
        -----------
        state: torch.tensor
            The state of the environment
        action: int
            the action to be taken
        count_dict: Dict
            The count dictionary
        action_space: List
            The action space for the agent
        turn: str
            The turn of the agent
        
        Returns:
        --------
        bool
            True if the state-action pair is a leaf node, False otherwise
            
            '''


        
        
        state_tuple = self.tensor_to_tuple(state)
      
        
        action_int = action if isinstance(action, int) else action_space.index(action)
        
        if turn == 'r':
            l = len(self.red_action_space_int)
        else:  
            l = len(self.blue_action_space_int) 

        val = count_dict.get(state_tuple, {}).get(turn, np.zeros(l))[action_int] == 0

        return val
    
    

    
    def search_stepv3(self, state, action_space_int, dynamics_func, count_dict, value_sum_dict, policy_dict, turn):
        '''
        Select and evaluate a state-action pair using the UCB algorithm
        
        Parameters:
        -----------
        state: torch.tensor
            The state of the environment
        action_space: List
            The action space for the agent
        dynamics_func: function
            The dynamics function for the agent
        count_dict: Dict
            The count dictionary
        value_sum_dict: Dict
            The value sum dictionary
        policy_dict: Dict
            The policy dictionary
        turn: str
            The turn of the agent
            
        Returns:
        --------
        bool
            True if the state-action pair is a leaf node, False otherwise
        torch.tensor
            The next state
        int
            The action to take
        torch.tensor
            The reward received
        torch.tensor
            The state received
            
        '''
  
        state_recived = state.clone()

        # action = self.arg_max_ucb(state, action_space, value_sum_dict, policy_dict, count_dict, turn)

        action = self.arg_max_ucb_parallel(state, action_space_int, value_sum_dict, policy_dict, count_dict, turn)
        
        is_leaf = self.check_leafv2(state, action, count_dict, action_space_int, turn)
        if is_leaf:
            next_state, reward = dynamics_func(state, action)

            self.state_transition_dict.setdefault(self.tensor_to_tuple(state), {'r': {}, 'b': {}})
            
            self.state_transition_dict[self.tensor_to_tuple(state)][turn][action] = (self.tensor_to_tuple(next_state), float(reward))
        else:

            tuple_next_state, float_reward = self.state_transition_dict[self.tensor_to_tuple(state)][turn][action]
            reward = float_reward
            next_state = torch.tensor(tuple_next_state).view(1, -1)
        return is_leaf, next_state, action, reward, state_recived

    
    def SEB(self, max_num_sims, initial_state, turn, policy_mask):
        '''
        Search, Evaluate and Backup the state providing the count based policy
        
        Parameters:
        -----------
        max_num_sims: int
            The maximum number of simulations to run
        initial_state: torch.tensor
            The initial state of the environment
        turn: str
            The turn of the agent
            
        Returns:
        --------
        torch.distributions.Categorical
            The policy for execution
            
            
        '''
    
       
        num_sims = 0
        original_turn = copy(turn)
        orignal_state = initial_state.clone()
        num_legal_actions = sum(policy_mask.values())


        if turn == 'b':

            policy_for_leaf, original_root_value = self.blue_prediction(initial_state)

            policy_for_leaf_np = policy_for_leaf.flatten()
            self.initalise_given_a_state(initial_state, self.count_dict ,self.policy_dict, self.value_sum_dict, policy_for_leaf_np, 'b')
            new_noisy_legal_policy = self.screened_policy_noise(policy_mask, policy_for_leaf_np, epsilon=0.2, alpha=10/num_legal_actions)

            self.write_policy(orignal_state, new_noisy_legal_policy, self.policy_dict, turn, policy_mask, is_dirichlet=True)
        else:
  
            policy_for_leaf, original_root_value = self.red_prediction(initial_state)
            policy_for_leaf_np = policy_for_leaf.flatten()

            self.initalise_given_a_state(initial_state, self.count_dict, self.policy_dict, self.value_sum_dict, policy_for_leaf_np, 'r')
            new_noisy_legal_policy = self.screened_policy_noise(policy_mask, policy_for_leaf_np, epsilon=0.2, alpha=10/num_legal_actions)
            self.write_policy(orignal_state, new_noisy_legal_policy, self.policy_dict, turn, policy_mask, is_dirichlet=True)
    
        while num_sims < max_num_sims:
            
            
            leaf_reached, state, turn = False, orignal_state, original_turn
            red_states_visted, red_actions_taken, red_rewards_recived = [],[],[]
            blue_states_visted, blue_actions_taken, blue_rewards_recived = [],[],[]

            depth = 0
        
            

            while (not leaf_reached) and (depth < self.max_depth):
                
    
                if turn == 'b':
                    leaf_reached, state, action, reward, state_recived = self.search_stepv3(state, self.blue_action_space_int, self.blue_dynamics, self.count_dict, self.value_sum_dict, self.policy_dict, 'b')
                   
                    blue_rewards_recived.append(reward)
                    blue_actions_taken.append(action)
                    blue_states_visted.append(state_recived)
                    turn = 'r'
                    
                else: 
                    leaf_reached, state, action, reward, state_recived = self.search_stepv3(state, self.red_action_space_int, self.red_dynamics, self.count_dict, self.value_sum_dict, self.policy_dict, 'r')
                   
                    red_rewards_recived.append(reward)
                    red_actions_taken.append(action)
                    red_states_visted.append(state_recived)
                    
                    turn = 'b'

           

                depth += 1 


            
            # need to update the stats using the final leaf turn
            
            if turn == 'b':
                leaf_predicted_pol, bleaf_predicted_val = self.blue_prediction(state)
               
                _, rleaf_predicted_val = self.red_prediction(state_recived)
                self.initalise_given_a_state(state, self.count_dict, self.policy_dict, self.value_sum_dict, leaf_predicted_pol, 'b')
                self.update_statsv4(blue_states_visted, blue_actions_taken, blue_rewards_recived, bleaf_predicted_val, self.count_dict, self.value_sum_dict, 'b', 'b')
                
                self.update_statsv4(red_states_visted, red_actions_taken, red_rewards_recived, rleaf_predicted_val, self.count_dict, self.value_sum_dict, 'r', 'b')
                
                # self.write_policy(state, leaf_predicted_pol, self.policy_dict, 'b')
                
                
                
            else:
               
                leaf_predicted_pol, rleaf_predicted_val = self.red_prediction(state)
                
                _, bleaf_predicted_val = self.blue_prediction(state_recived)
                self.initalise_given_a_state(state, self.count_dict, self.policy_dict, self.value_sum_dict, leaf_predicted_pol, 'r')
                # self.write_policy(state, leaf_predicted_pol, self.policy_dict, 'r')
            
                self.update_statsv4(red_states_visted, red_actions_taken, red_rewards_recived, rleaf_predicted_val, self.count_dict, self.value_sum_dict, 'r', 'r')
                self.update_statsv4(blue_states_visted, blue_actions_taken, blue_rewards_recived, bleaf_predicted_val, self.count_dict, self.value_sum_dict, 'b', 'r')
            
            
            
            num_sims += 1

        # print('-'*100)
        # print(self.tensor_to_tuple(orignal_state))
        # print(self.policy_dict[self.tensor_to_tuple(orignal_state)][original_turn])
        # print(self.count_dict[self.tensor_to_tuple(orignal_state)][original_turn])
        # print('-'*100)

        return self.get_execution_policy(orignal_state, original_turn), original_root_value

    
    def get_execution_policy(self, state, turn):
        ''' Get the execution policy
        
        Parameters:
        -----------
        state: torch.tensor
            The state of the environment
        turn: str
            The turn of the agent
            
        Returns:
        --------
        torch.distributions.Categorical
            The policy for execution
        '''
        
        action_space = self.red_action_space if turn == 'r' else self.blue_action_space
        probs = self.get_count_based_probsv2(state, self.count_dict, action_space, turn)
        # probs = self.get_highest_q_policy(state, self.value_sum_dict, action_space, turn)

        return probs

    
    def get_count_based_probsv2(self, state, count_dict, action_space, turn):
        ''' Get the count based probabilities
        
        Parameters:
        -----------
        
        state: torch.tensor
            The state of the environment
        count_dict: Dict
            The count dictionary
        action_space: List
            The action space for the agent
        turn: str
            The turn of the agent
            
        Returns:
        --------
        torch.tensor
            The count based probabilities
        '''

        # policy = torch.zeros((1, len(action_space)), dtype=torch.float32)
        policy = np.zeros(len(action_space))
        state_tuple = self.tensor_to_tuple(state)

        total_count = sum(count_dict[state_tuple][turn])
        
        policy = count_dict[state_tuple][turn] / total_count
      
  
        return policy
    
    @njit
    def add_dirichlet_noise(self, prior, epsilon=0.25, alpha=0.25):
        ''' Add Dirichlet noise to the prior
        
        Parameters:
        -----------
        
        prior: np.array
            The prior to add noise to
        epsilon: float
            The epsilon value
        alpha: float
            The alpha value
        '''

        # Sample noise from Dirichlet distribution
        dirichlet_noise = np.random.dirichlet([alpha] * len(prior))

        # Combine the prior with the Dirichlet noise
        
        return (1 - epsilon) * prior + epsilon * dirichlet_noise
    
    
    def screened_policy_noise(self, action_mask: np.array, flat_np_policy: np.array, epsilon=0.25, alpha=0.25):
        # new_polciy = torch.zeros((1, len(policy.probs)), dtype=torch.float32)
        
        
        num_legal_actions = sum(action_mask)
       
       
        # num_illiegal_action = len(action_mask.values()) - num_legal_actions
        legal_problity_mass = sum([prob if action_mask[i]== 1 else 0 for i, prob in  enumerate(flat_np_policy)])

        illiegal_problity_mass = 1 - legal_problity_mass

        if legal_problity_mass == 0:
            new_policy =  [1/num_legal_actions if action_mask[i]== 1 else 0 for i, _ in enumerate(flat_np_policy)]

        else:
            addative_factor = illiegal_problity_mass/num_legal_actions
            new_policy = [prob + addative_factor if action_mask[i]== 1 else 0 for i, prob in enumerate(flat_np_policy)]

        dirichlet_noise = np.random.dirichlet([alpha] * num_legal_actions)

        # Combine the prior with the Dirichlet noise
    
        # new_noisy_legal_policy = np.array([((1 - epsilon) * prob + epsilon * dirichlet_noise[i]) if action_mask[i]== 1 else 0 for i, prob in enumerate(new_policy)])
        new_noisy_legal_policy = np.zeros(len(flat_np_policy))
        count = 0
        for i, prob in enumerate(new_policy):

            if action_mask[i] == 1:
                new_noisy_legal_policy[i] = (1 - epsilon) * prob + epsilon * dirichlet_noise[count]
                count += 1
            else:
                new_noisy_legal_policy[i] = 0

        new_noisy_legal_policy = (torch.tensor(new_noisy_legal_policy)).view(1,-1)


        return(new_noisy_legal_policy)
    
    
############################################################################################################################################################################

#TESTING

#region

class PredictionNet(nn.Module):
    def __init__(self, action_space, hidden_size):
        super().__init__()
        
        self.action_space = action_space
        self.hidden_size = hidden_size
        
        self.hidden_function_head = nn.Sequential(
            nn.Linear((hidden_size), 128),
            nn.SELU()
        )
        
        self.value_head = nn.Sequential(
           
            nn.Linear(128, 1)
        )
        
        self.policy_head = nn.Sequential(
            nn.Linear(128, len(self.action_space)),
            nn.ReLU(),
            nn.Softmax(dim=1)
        )
        
    def forward(self, x):
        x = self.hidden_function_head(x)
        value = self.value_head(x)
        policy = self.policy_head(x)
        return policy, value
        
class DynamicsNet(nn.Module):
    def __init__(self, hidden_size):
        super().__init__()
        
        self.hidden_size = hidden_size
        
        self.hidden_function_head = nn.Sequential(
            nn.Linear((hidden_size+3), 128),
            nn.SELU()
        )
        
        self.reward_head = nn.Sequential(
            nn.Linear(128, 1)
        )
        
        self.next_state_head = nn.Sequential(
            nn.Linear(128, hidden_size)
        )
        
        
    def forward(self, x):
        x = self.hidden_function_head(x)
        reward = self.reward_head(x)
        next_state = self.next_state_head(x)
        return next_state, reward

def test_init():
    
    red_action_space = ['a', 'b', 'c']
    blue_action_space = ['d', 'e', 'f']
    
    red_prediction_net = PredictionNet(red_action_space, 5)
    red_dynamics_net = DynamicsNet(5)
    blue_prediction_net = PredictionNet(blue_action_space, 5)
    blue_dynamics_net = DynamicsNet(5)
    
    searcher = Search(red_action_space, red_prediction_net, red_dynamics_net,
                      blue_action_space, blue_prediction_net, blue_dynamics_net)
    
    assert searcher.red_action_space == red_action_space
    assert searcher.red_prediction_net == red_prediction_net
    assert searcher.red_dynamics_net == red_dynamics_net
    assert searcher.blue_action_space == blue_action_space
    assert searcher.blue_prediction_net == blue_prediction_net
    assert searcher.blue_dynamics_net == blue_dynamics_net
    assert searcher.count_dict == {}
    assert searcher.value_sum_dict == {}
    assert searcher.state_transition_dict == {}
    assert searcher.policy_dict == {}
    assert searcher.red_max_value == 1
    assert searcher.blue_max_value == 1
    assert searcher.red_min_value == 0
    assert searcher.blue_min_value == 0
    assert searcher.mean_red_value == 0
    assert searcher.mean_blue_value == 0
    assert searcher.red_value_count == 0
    assert searcher.blue_value_count == 0
    assert searcher.c1 == 1.25
    assert searcher.c2 == 19652
    assert searcher.discount_factor == 0.99

def test_tensor_to_tuple():
    searcher = Search([], None, None, [], None, None)
    tensor = torch.tensor([1, 2, 3, 4, 5])
    assert searcher.tensor_to_tuple(tensor) == (1, 2, 3, 4, 5)
       
def test_transform_value():
    searcher = Search([], None, None, [], None, None)
    assert searcher.transform_value(0, 'r') == 0
    assert searcher.transform_value(0, 'b') == 0
    assert searcher.transform_value(1, 'r') == 1
    assert searcher.transform_value(1, 'b') == 1
    assert searcher.transform_value(0.5, 'r') == 0.5
    assert searcher.transform_value(0.5, 'b') == 0.5
    
    searcher.red_max_value = 2
    searcher.red_min_value = 0
    searcher.red_value_count = 1
    searcher.mean_red_value = 1
    assert searcher.transform_value(1, 'r') == 0.5
    
    searcher.blue_max_value = 2
    searcher.blue_min_value = 0
    searcher.blue_value_count = 1
    searcher.mean_blue_value = 1
    assert searcher.transform_value(1, 'b') == 0.5
    
    assert searcher.transform_value(None, 'r') == 0
    assert searcher.transform_value(None, 'b') == 0
    
def test_action_ohe():
    searcher = Search(['a', 'b', 'c'], None, None, ['d', 'e', 'f'], None, None)
    action = 'a'
    action_space = ['a', 'b', 'c']
    assert torch.all(searcher.action_ohe(action, action_space) == torch.tensor([[1, 0, 0]]))
    
    action = 1
    action_space = ['a', 'b', 'c']
    assert torch.all(searcher.action_ohe(action, action_space) == torch.tensor([[0, 1, 0]]))
    
def test_action_to_int():
    searcher = Search(['a', 'b', 'c'], None, None, ['d', 'e', 'f'], None, None)
    action = 'a'
    action_space = ['a', 'b', 'c']
    assert searcher.action_to_int(action, action_space) == 0
    
    action = 'b'
    action_space = ['a', 'b', 'c']
    assert searcher.action_to_int(action, action_space) == 1
    
    action = 'c'
    action_space = ['a', 'b', 'c']
    assert searcher.action_to_int(action, action_space) == 2
    
def test_int_to_action():
    searcher = Search(['a', 'b', 'c'], None, None, ['d', 'e', 'f'], None, None)
    number = 0
    action_space = ['a', 'b', 'c']
    assert searcher.int_to_action(number, action_space) == 'a'
    
    number = 1
    action_space = ['a', 'b', 'c']
    assert searcher.int_to_action(number, action_space) == 'b'
    
    number = 2
    action_space = ['a', 'b', 'c']
    assert searcher.int_to_action(number, action_space) == 'c'
        
def test_ucb_value():
    searcher = Search(['a', 'b', 'c'], None, None, ['d', 'e', 'f'], None, None)
    state = torch.tensor([[1, 2, 3, 4, 5]])
    action = 'a'
    mean_value = {searcher.tensor_to_tuple(state): {'r': {0: 0.5}, 'b': {0: 0.5}}}
    policy = {searcher.tensor_to_tuple(state): {'r': {0: 0.5, 1: 0.5}, 'b': {0: 0.5}}}
    visit_count = {searcher.tensor_to_tuple(state): {'r': {0: 1}, 'b': {0: 1}}}
    action_space = ['a', 'b', 'c']
    turn = 'r'
    correct = 0.5 + 0.5 * np.sqrt(1) / (1 + 1) * (1.25 + np.log((1 + 19652 + 1) / 19652))
    
    assert searcher.ucb_value(state, action, mean_value, policy, visit_count, action_space, turn) == correct
    
def test_write_policy():
    searcher = Search(['a', 'b', 'c'], None, None, ['d', 'e', 'f'], None, None)
    state = torch.tensor([[1, 2, 3, 4, 5]])
    policy = torch.tensor([[0.5, 0.3, 0.2]])
    policy_dict = {}
    turn = 'r'
    searcher.initalise_given_a_state(state, {}, policy_dict, {}, policy, turn)
    searcher.write_policy(state, policy, policy_dict, turn)
   
def test_get_discounted_rewards():
    searcher = Search(['a', 'b', 'c'], None, None, ['d', 'e', 'f'], None, None)
    rewards = [torch.tensor([[1]]), torch.tensor([[2]]), torch.tensor([[3]])]
    leaf_value = torch.tensor([[0.5]])
    correct =  1 + 0.99 * (2 + 0.99 * (3 + 0.99 * 0.5))

    assert searcher.get_discounted_rewards(rewards, leaf_value, 0.99) == correct
    
def test_initalise_given_a_state():
    searcher = Search(['a', 'b', 'c'], None, None, ['d', 'e', 'f'], None, None)
    state = torch.tensor([[1, 2, 3, 4, 5]])
    count_dict = {}
    policy_dict = {}
    value_sum_dict = {}
    policy_for_leaf = torch.tensor([[0.5, 0.3, 0.2]])
    turn = 'r'
    searcher.initalise_given_a_state(state, count_dict, policy_dict, value_sum_dict, policy_for_leaf, turn)
     
def test_check_leafv2():
    searcher = Search(['a', 'b', 'c'], None, None, ['d', 'e', 'f'], None, None)
    state = torch.tensor([[1, 2, 3, 4, 5]])
    action = 'a'
    count_dict = {(1, 2, 3, 4, 5): {'r': {0: 1}, 'b': {}}}
    action_space = ['a', 'b', 'c']
    turn = 'r'
    assert searcher.check_leafv2(state, action, count_dict, action_space, turn) == False
    assert searcher.check_leafv2(state, 'b', count_dict, action_space, turn) == True
    
    
    assert searcher.check_leafv2(state, 'd', count_dict, ['d', 'e', 'f'], 'b') == True
    
def test_search_stepv3():
    
    red_dynamics = DynamicsNet(5)  
    blue_dynamics = DynamicsNet(5)
    
    searcher = Search(['a', 'b', 'c'], None, red_dynamics, ['d', 'e', 'f'], None, blue_dynamics)
    state = torch.tensor([[1, 2, 3, 4, 5]])
    count_dict = {}
    value_sum_dict = {}
    policy_dict = {}
    turn = 'r'
    searcher.initalise_given_a_state(state, count_dict, policy_dict, value_sum_dict, torch.tensor([[0.5, 0.3, 0.2]]), turn)
    is_leaf, next_state, action, reward, state_recived = searcher.search_stepv3(state, ['a', 'b', 'c'], searcher.red_dynamics, count_dict, value_sum_dict, policy_dict, turn)
    print(is_leaf, next_state, action, reward, state_recived)
    assert is_leaf == True
    assert next_state.shape == (1, 5)
    assert action in [0, 1, 2]
    assert reward.shape == (1, 1)
    assert state_recived.shape == (1, 5)
    
def test_SEB():
    red_action_space = ['a', 'b', 'c']
    blue_action_space = ['d', 'e', 'f']
    
    red_prediction_net = PredictionNet(red_action_space, 5)
    red_dynamics_net = DynamicsNet(5)
    blue_prediction_net = PredictionNet(blue_action_space, 5)
    blue_dynamics_net = DynamicsNet(5)
    
    searcher = Search(red_action_space, red_prediction_net, red_dynamics_net,
                      blue_action_space, blue_prediction_net, blue_dynamics_net)
    
    initial_state = torch.tensor([[1, 2, 3, 4, 5]], dtype=torch.float32)
    turn = 'r'
    policy, _ = searcher.SEB(10, initial_state, turn)
    assert policy.logits.shape == (1, 3)
    
def test_get_count_based_probs():
    searcher = Search(['a', 'b', 'c'], None, None, ['d', 'e', 'f'], None, None)
    state = torch.tensor([[1, 2, 3, 4, 5]])
    count_dict = {(1, 2, 3, 4, 5): {'r': {0: 1, 1: 1, 2: 1}, 'b': {0: 1, 1: 1, 2: 1}}}
    action_space = ['a', 'b', 'c']
    turn = 'r'
    
    assert torch.all(searcher.get_count_based_probs(state, count_dict, action_space, turn) == torch.tensor([[1/3, 1/3, 1/3]]))
    
def test_dirichlet_noise():
    tesnor_of_probs = torch.tensor([1/1000]*67, dtype=torch.float32)
    tesnor_of_probs[1] = 1 - 1/1000*66
    tesnor_of_probs = tesnor_of_probs.numpy()
   
    
    searcher = Search(['a', 'b', 'c'], None, None, ['d', 'e', 'f'], None, None)
    noisy_probs = searcher.add_dirichlet_noise(tesnor_of_probs, epsilon=0.25, alpha=300)
   
def test_update_statsv2():
    searcher = Search(['a', 'b', 'c'], None, None, ['d', 'e', 'f'], None, None)
    states = [torch.tensor([[1, 2, 3, 4, 5]])]
    actions_ints = [0]
    rewards = [torch.tensor([[1]])]
    leaf_value = torch.tensor([[0.5]])
    count_dict = {}
    value_sum_dict = {}
    turns = 'r'
    searcher.initalise_given_a_state(states[0], count_dict, {}, value_sum_dict, torch.tensor([[0.5, 0.3, 0.2]]), 'r')
    searcher.update_statsv2(states, actions_ints, rewards, leaf_value, count_dict, value_sum_dict, turns)
    assert count_dict == {(1, 2, 3, 4, 5): {'r': {0: 1}, 'b': {}}}
    print(value_sum_dict)
    assert value_sum_dict == {(1, 2, 3, 4, 5): {'r': {0: 1+0.5*0.99}, 'b':{}}}
    
if __name__ == '__main__':
    test_init()
    # test_tensor_to_tuple()
    # test_transform_value()
    # test_action_ohe()
    # test_action_to_int()
    # test_int_to_action()
    # test_ucb_value()
    # test_write_policy()


    # test_get_discounted_rewards()
    # test_initalise_given_a_state()
    # test_check_leafv2()
    # test_search_stepv3()
    # test_SEB()
    # # test_get_count_based_probs()
    # test_dirichlet_noise()
    # test_update_statsv2()
    print('All tests passed')  

#endregion