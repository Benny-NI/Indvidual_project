import numpy as np
import torch
import torch.nn.functional as F
from numba import jit, njit
from typing import List

def soft_temp_max(x: torch.tensor, temp:float = 1) -> np.ndarray:
    sfm = F.softmax(x/temp, dim=1)
    return sfm.detach().numpy()

@jit
def scalar_to_categorical_not_vector(x: float, support_set: np.ndarray) -> List[np.ndarray]:
    # Scale the value (using your existing scaling function)
    
    # Find the two nearest support values
    support_low_idx = np.searchsorted(support_set, x, side='right') - 1
    support_low = support_set[support_low_idx]
    
    # Clip to ensure within bounds
    if support_low_idx == len(support_set) - 1:
        support_high = support_low  # If it's at the highest value
    else:
        support_high = support_set[support_low_idx + 1]
    
    # Calculate the weights for the low and high support values
    if support_high != support_low:
        high_weight = (x - support_low) / (support_high - support_low)
    else:
        high_weight = 1.0  # If low and high are the same, all weight is on that value
    
    low_weight = 1 - high_weight
    
    return support_low, low_weight, support_high, high_weight

@jit
def sftm_categorical_to_value(softmax_probs: np.ndarray, support_set: np.ndarray) -> np.ndarray:
    
    # Compute the expected value as the weighted sum of the support set values
   
    expected_value = np.sum(softmax_probs * support_set)

    return expected_value


def kl_div_loss_support(network_output: torch.tensor, true_value: float, support_set:np.ndarray) -> torch.tensor:
     # Convert the true value to a categorical target
    support_low, low_weight, support_high, high_weight = scalar_to_categorical_not_vector(true_value, support_set)
    
    # Find the index of support_low and support_high in the support set
    support_low_idx = np.searchsorted(support_set, support_low, side='left')
    support_high_idx = np.searchsorted(support_set, support_high, side='left')

    support_low_idx = int(support_low_idx)
    support_high_idx = int(support_high_idx)
    low_weight = float(low_weight)
    high_weight = float(high_weight)
    
    # One-hot encode the categorical target with the appropriate weights
    target_probs = torch.zeros_like(network_output)  # Create a zero tensor with same size as output
    target_probs[:, support_low_idx] = low_weight
    target_probs[:, support_high_idx] = high_weight


    # Compute cross-entropy loss
    loss = kl_div_loss(network_output, target_probs)
    return loss

def kl_div_loss(network_output: torch.tensor, target_probs:torch.tensor) -> torch.tensor:
    log_probs = F.log_softmax(network_output, dim=1)  # Convert network output to log probabilities
    loss = F.kl_div(log_probs, target_probs, reduction='batchmean', log_target=False)
    return loss


def test_full_conversion():
    value_step = 1  
    value_support_set = np.arange(0, 100 + value_step, value_step)

    a_raw_networks_output = torch.randn((1,101))

    soft_maxed = soft_temp_max(a_raw_networks_output)

    the_predicted_value = sftm_categorical_to_value(soft_maxed, value_support_set)

    catagorical_rep = scalar_to_categorical_not_vector(the_predicted_value, value_support_set)

    # the_recovered_softmaxed_catagory = scalar_to_vector(the_predicted_value, value_support_set)
    
    print(soft_maxed)
    print(the_predicted_value)
    print(catagorical_rep)
   


if __name__ == '__main__':
    test_full_conversion()


    