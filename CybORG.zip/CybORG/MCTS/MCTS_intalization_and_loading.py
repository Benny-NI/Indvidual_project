import os
import torch
import torch.nn as nn
import torch.optim as optim
import inspect
from CybORG import CybORG
from CybORG.Agents.Wrappers.SelfPlayWrapperv3 import SelfPlayWrapperv3
from time import sleep, time
from CybORG.Simulator.Scenarios import FileReaderScenarioGenerator
from MCTS.Models_with_just_the_observation import prediction_function, representation_function, dynamics_function





def initalize_optimizer(red_dynamics, red_prediction, red_hidden_state, blue_dynamics, blue_prediction, blue_hidden_state):
    '''
    Initialize the optimizer
    
    Parameters:
    -----------
    red_dynamics: nn.Module
        The red dynamics model
    red_prediction: nn.Module
        The red prediction model
    red_hidden_state: nn.Module
        The red hidden state model
    blue_dynamics: nn.Module
        The blue dynamics model
    blue_prediction: nn.Module
        The blue prediction model
    blue_hidden_state: nn.Module
        The blue hidden state model
        
    Returns:
    --------
    optimizer: optim.AdamW
        The optimizer
    
    '''
    
    optimizer = optim.AdamW(
        list(red_hidden_state.parameters()) + list(red_dynamics.parameters()) + list(red_prediction.parameters()) +
        list(blue_hidden_state.parameters()) + list(blue_dynamics.parameters()) + list(blue_prediction.parameters()), 
        lr=3e-2
    )
    
    return optimizer

def save_optimizers(optimizer, path_to_optimizers):
    '''
    Save the optimizers
    
    Parameters:
    -----------
    optimizer: optim.AdamW
        The optimizer
    path_to_optimizers: str
        Path to the optimizers
    
    '''
    time_to_save = time()
    os.makedirs(f'{path_to_optimizers}/{time_to_save}')

    torch.save(optimizer.state_dict(), f'{path_to_optimizers}/{time_to_save}/optimizer.pt')

def load_latest_optimizers(path_to_optimizers, red_dynamics, red_prediction, red_hidden_state, blue_dynamics, blue_prediction, blue_hidden_state):
    '''
    Load the latest optimizers
    
    Parameters:
    -----------
    path_to_optimizers: str
        Path to the optimizers
    
    Returns:
    --------
    optimizer: optim.AdamW
        The optimizer
    
    '''
    
    latest_optimizer = max(os.listdir(path_to_optimizers), default=None)

    if not latest_optimizer or latest_optimizer == '.DS_Store':
        print('No optimizers found, initializing new optimizer')
        return initalize_optimizer(red_dynamics, red_prediction, red_hidden_state, blue_dynamics, blue_prediction, blue_hidden_state)
    
    latest_optimizer = f'{path_to_optimizers}/{latest_optimizer}/optimizer.pt'
    optimizer_sd = torch.load(latest_optimizer, weights_only=True)  
    optimizer = initalize_optimizer(red_dynamics, red_prediction, red_hidden_state, blue_dynamics, blue_prediction, blue_hidden_state)
    optimizer.load_state_dict(optimizer_sd)
    
    return optimizer

def save_models(red_dynamics, red_prediction, red_hidden_state,
                blue_dynamics, blue_prediction, blue_hidden_state,
                path_to_models):
    '''
    Save the models
    
    Parameters:
    -----------
    red_dynamics: nn.Module
        The red dynamics model
    red_prediction: nn.Module
        The red prediction model
    red_hidden_state: nn.Module
        The red hidden state model
    blue_dynamics: nn.Module
        The blue dynamics model
    blue_prediction: nn.Module
        The blue prediction model
    blue_hidden_state: nn.Module
        The blue hidden state model
    path_to_models: str
        Path to the models
    
    Returns:
    --------
    new_path_to_models: str
        The new path to the models
        
    '''
        
    
    save_time = time()
    new_path_to_models = f'{path_to_models}/{save_time}'

    os.makedirs(f'{new_path_to_models}/red')
    os.makedirs(f'{new_path_to_models}/blue')

    torch.save(red_dynamics.state_dict(), f'{new_path_to_models}/red/red_dyn_{save_time}.pt')
    torch.save(red_prediction.state_dict(), f'{new_path_to_models}/red/red_pred_{save_time}.pt')
    torch.save(red_hidden_state.state_dict(), f'{new_path_to_models}/red/red_rep_{save_time}.pt')
    torch.save(blue_dynamics.state_dict(), f'{new_path_to_models}/blue/blue_dyn_{save_time}.pt')
    torch.save(blue_prediction.state_dict(), f'{new_path_to_models}/blue/blue_pred_{save_time}.pt')
    torch.save(blue_hidden_state.state_dict(), f'{new_path_to_models}/blue/blue_rep_{save_time}.pt')

    return new_path_to_models

def initialize_models():
    '''
    Initialize the models
    
    Returns:
    --------
    red_dynamics: nn.Module
        The red dynamics model
    red_prediction: nn.Module
        The red prediction model
    red_hidden_state: nn.Module
        The red hidden state model
    blue_dynamics: nn.Module
        The blue dynamics model
    blue_prediction: nn.Module
        The blue prediction model
    blue_hidden_state: nn.Module
        The blue hidden state model
        
    '''
    path = str(inspect.getfile(CybORG))
    path = path[:-7] + '/Simulator/Scenarios/scenario_files/Scenario1b.yaml'
    sg = FileReaderScenarioGenerator(path)

    
    cyborg = CybORG(sg, 'sim')
    env = SelfPlayWrapperv3(env=cyborg)

    red_reset_result, blue_reset_result = env.reset()
    hidden_state_size = 64


    size_red_observation_space = len(red_reset_result.observation)
    red_action_space = red_reset_result.action_space
    red_dynamics = dynamics_function(red_action_space, hidden_state_size)
    red_prediction = prediction_function(red_action_space, hidden_state_size)
    red_hidden_state = representation_function(size_red_observation_space, red_action_space, hidden_state_size)

    size_blue_observation_space = len(blue_reset_result.observation)
    blue_action_space = blue_reset_result.action_space
    blue_dynamics = dynamics_function(blue_action_space, hidden_state_size)
    blue_prediction = prediction_function(blue_action_space, hidden_state_size)
    blue_hidden_state = representation_function(size_blue_observation_space, blue_action_space, hidden_state_size)

    path_to_model_storage = 'Models_puct2_self_play_adam_PER'
    _ = save_models(red_dynamics, red_prediction, red_hidden_state, blue_dynamics, blue_prediction, blue_hidden_state, path_to_model_storage)

    return red_dynamics, red_prediction, red_hidden_state, blue_dynamics, blue_prediction, blue_hidden_state

def get_latest_model_versions(path_to_model_storage):
    
    '''
    Get the latest model versions
    
    Parameters:
    -----------
    path_to_model_storage: str
        Path to the model storage
    
    Returns:
    --------
    red_dynamics: nn.Module
        The red dynamics model
    red_prediction: nn.Module
        The red prediction model
    red_hidden_state: nn.Module
        The red hidden state model
    blue_dynamics: nn.Module
        The blue dynamics model
    blue_prediction: nn.Module
        The blue prediction model
    blue_hidden_state: nn.Module
    
    '''
    
    
    latest_w_and_b = max(os.listdir(path_to_model_storage), default=None)

    if not latest_w_and_b or latest_w_and_b == '.DS_Store':
        print('No models found, initializing new models')
        return initialize_models()
    
    latest_w_and_b = f'{path_to_model_storage}/{latest_w_and_b}'
    path_to_agent_weights_red = f'{latest_w_and_b}/red'
    path_to_agent_weights_blue = f'{latest_w_and_b}/blue'

    print(f'Latest model version: {latest_w_and_b}')
    red_rep_name = next(name for name in os.listdir(path_to_agent_weights_red) if name.startswith('red_rep'))
    red_dyn_name = next(name for name in os.listdir(path_to_agent_weights_red) if name.startswith('red_dyn'))
    red_pred_name = next(name for name in os.listdir(path_to_agent_weights_red) if name.startswith('red_pre'))

    blue_rep_name = next(name for name in os.listdir(path_to_agent_weights_blue) if name.startswith('blue_rep'))
    blue_dyn_name = next(name for name in os.listdir(path_to_agent_weights_blue) if name.startswith('blue_dyn'))
    blue_pred_name = next(name for name in os.listdir(path_to_agent_weights_blue) if name.startswith('blue_pre'))

    red_hidden_state_sd = torch.load(f'{path_to_agent_weights_red}/{red_rep_name}', weights_only=True)  
    red_dynamics_sd = torch.load(f'{path_to_agent_weights_red}/{red_dyn_name}', weights_only=True)  
    red_prediction_sd = torch.load(f'{path_to_agent_weights_red}/{red_pred_name}', weights_only=True)  

    blue_hidden_state_sd = torch.load(f'{path_to_agent_weights_blue}/{blue_rep_name}', weights_only=True)   
    blue_dynamics_sd = torch.load(f'{path_to_agent_weights_blue}/{blue_dyn_name}', weights_only=True)  
    blue_prediction_sd = torch.load(f'{path_to_agent_weights_blue}/{blue_pred_name}', weights_only=True)  

    path = str(inspect.getfile(CybORG))
    path = path[:-7] + '/Simulator/Scenarios/scenario_files/Scenario1b.yaml'
    sg = FileReaderScenarioGenerator(path)

    cyborg = CybORG(sg, 'sim')

    env = SelfPlayWrapperv3(env=cyborg)

    red_reset_result, blue_reset_result = env.reset()
    hidden_state_size = 64

    size_red_observation_space = len(red_reset_result.observation)
    red_action_space = red_reset_result.action_space
    red_dynamics = dynamics_function(red_action_space, hidden_state_size)
    red_prediction = prediction_function(red_action_space, hidden_state_size)
    red_hidden_state = representation_function(size_red_observation_space, red_action_space, hidden_state_size)

    size_blue_observation_space = len(blue_reset_result.observation)
    blue_action_space = blue_reset_result.action_space
    blue_dynamics = dynamics_function(blue_action_space, hidden_state_size)
    blue_prediction = prediction_function(blue_action_space, hidden_state_size)
    blue_hidden_state = representation_function(size_blue_observation_space, blue_action_space, hidden_state_size)

    red_dynamics.load_state_dict(red_dynamics_sd)
    red_prediction.load_state_dict(red_prediction_sd)
    red_hidden_state.load_state_dict(red_hidden_state_sd)


    blue_dynamics.load_state_dict(blue_dynamics_sd)
    blue_prediction.load_state_dict(blue_prediction_sd)
    blue_hidden_state.load_state_dict(blue_hidden_state_sd)

    return red_dynamics, red_prediction, red_hidden_state, blue_dynamics, blue_prediction, blue_hidden_state

