import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F



class prediction_function(nn.Module):
    def __init__(self, action_space, hidden_size, dropout_prob = 0.2):
        super().__init__()

        self.dropout_prob = dropout_prob
        self.action_space = action_space
        self.hidden_size = hidden_size
        self.support_v_set_size = 101

        self.hidden_function_head = nn.Sequential(
            nn.Linear((hidden_size), hidden_size),
            nn.LeakyReLU(),
            nn.Dropout(self.dropout_prob),
            nn.Linear(hidden_size, hidden_size),
            nn.LeakyReLU()
        )
        
        self.res_1 = self.get_resnet()
        self.res_2 = self.get_resnet()
        self.res_3 = self.get_resnet()
        self.res_4 = self.get_resnet()
        self.res_5 = self.get_resnet()
        
        self.hidden_function_tail_p = nn.Sequential(
            nn.Dropout(self.dropout_prob),
            nn.Linear(hidden_size, hidden_size),
            nn.LeakyReLU(),
            nn.Linear(hidden_size, hidden_size),
            nn.LeakyReLU(),
            nn.Linear(hidden_size, len(self.action_space))
        )
        self.hidden_function_tail_v = nn.Sequential(
            nn.Dropout(self.dropout_prob),
            nn.Linear(hidden_size, hidden_size),
            nn.LeakyReLU(),
            nn.Linear(hidden_size, hidden_size),
            nn.LeakyReLU(),
            nn.Linear(hidden_size, self.support_v_set_size)

            
            
        )
            
            
    def get_resnet(self):
            res_net = nn.Sequential(
                # nn.Dropout(self.dropout_prob),
                nn.Linear(self.hidden_size, self.hidden_size),
                nn.LeakyReLU(),
                # nn.Dropout(self.dropout_prob),
                nn.Linear(self.hidden_size, self.hidden_size),
                nn.LeakyReLU()
            )
            return res_net
     
    def forward(self, x):
        
        x = self.hidden_function_head(x)
        
        x = self.res_1(x) + x
        x = self.res_2(x) + x
        x = self.res_3(x) + x
        x = self.res_4(x) + x
        x = self.res_5(x) + x
        
        p = self.hidden_function_tail_p(x)
        v = self.hidden_function_tail_v(x)

        
        
        return p, v
    

class dynamics_function(nn.Module):
    def __init__(self, action_space, hidden_size, dropout_prob = 0.2):
        super().__init__()

        self.dropout_prob = dropout_prob
        self.action_space = action_space
        self.hidden_size = hidden_size
        self.support_r_set_size = 201
        
        self.hidden_function_head = nn.Sequential(
            nn.Linear((hidden_size+len(action_space)), hidden_size),
            nn.LeakyReLU(),
            nn.Dropout(self.dropout_prob),
            nn.Linear(hidden_size, hidden_size),
            nn.LeakyReLU()
        )
        
        self.res_1 = self.get_resnet()
        self.res_2 = self.get_resnet()
        self.res_3 = self.get_resnet()
        self.res_4 = self.get_resnet()
        self.res_5 = self.get_resnet()
        
        self.hidden_function_tail_state = nn.Sequential(
            nn.Dropout(self.dropout_prob),
            nn.Linear(hidden_size, hidden_size),
            nn.LeakyReLU(),
            nn.Dropout(self.dropout_prob),
            nn.Linear(hidden_size, self.hidden_size),
            nn.Sigmoid()
        )
            
        self.hidden_function_tail_reward = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.LeakyReLU(),
            nn.Dropout(self.dropout_prob),
            nn.Linear(hidden_size, self.support_r_set_size),
            # nn.Softmax(dim=1)
        )
            
            
    def get_resnet(self):
            res_net = nn.Sequential(
                # nn.Dropout(self.dropout_prob),
                nn.Linear(self.hidden_size, self.hidden_size),
                nn.LeakyReLU(),
                # nn.Dropout(self.dropout_prob),
                nn.Linear(self.hidden_size, self.hidden_size),
                nn.LeakyReLU(),
            )
            return res_net
     
    def forward(self, x):
        
        x = self.hidden_function_head(x)
        
        x = self.res_1(x) + x
        x = self.res_2(x) + x
        x = self.res_3(x) + x
        x = self.res_4(x) + x
        x = self.res_5(x) + x
        
        state = self.hidden_function_tail_state(x)
        reward = self.hidden_function_tail_reward(x)
        
        return state, reward   
     
    
class representation_function(nn.Module):
    def __init__(self, state_space, action_space, hidden_size, dropout_prob = 0.2):
        super().__init__()
    

        self.dropout_prob = dropout_prob
        self.state_space = state_space
        self.action_space = action_space
        self.history_depth = 1
        self.hidden_size = hidden_size
        self.hidden_function_head_input_size = self.history_depth*self.state_space

        self.hidden_function_head = nn.Sequential(
            nn.Linear(self.hidden_function_head_input_size, 64),
            nn.LeakyReLU(),
            nn.Dropout(self.dropout_prob),
            nn.Linear(64, hidden_size),
            nn.LeakyReLU()
        )
        
        self.res_1 = self.get_resnet()
        self.res_2 = self.get_resnet()
        self.res_3 = self.get_resnet()
        self.res_4 = self.get_resnet()
        self.res_5 = self.get_resnet()
        
        self.hidden_function_tail = nn.Sequential(
            nn.Dropout(self.dropout_prob),
            nn.Linear(hidden_size, hidden_size),
            nn.LeakyReLU(),
            nn.Dropout(self.dropout_prob),
            nn.Linear(hidden_size, hidden_size),
            nn.Sigmoid()
        )
            
            
            
    def get_resnet(self):
            res_net = nn.Sequential(
                # nn.Dropout(self.dropout_prob),
                nn.Linear(self.hidden_size, self.hidden_size),
                nn.LeakyReLU(),
                # nn.Dropout(self.dropout_prob),
                nn.Linear(self.hidden_size, self.hidden_size),
                nn.LeakyReLU()
            )
            return res_net
     
    def forward(self, x):
        
        x = self.hidden_function_head(x)
        
        x = self.res_1(x) + x
        x = self.res_2(x) + x
        x = self.res_3(x) + x
        x = self.res_4(x) + x
        x = self.res_5(x) + x
        
        x = self.hidden_function_tail(x)
        
        return x     
     
    