import torch
import os
import torch.optim as optim
import torch.nn as nn
import copy
from time import time, sleep
from MCTS.MCTS_value_wrangeling import kl_div_loss, kl_div_loss_support
from MCTS.MCTS_intalization_and_loading import load_latest_optimizers, save_optimizers
import numpy as np

reward_step = 0.005
reward_support_set = np.arange(0, 1 + reward_step, reward_step)

value_step = 1
value_support_set = np.arange(0, 100 + value_step, value_step)



def get_rew_pols_vals(trajectory, red_hidden_state, red_prediction, red_dynamics, blue_hidden_state, blue_prediction, blue_dynamics, history_depth=1, unroll_depth=5, boostrap_depth=10):

    
    red_start_outputs = {}
    blue_start_outputs = {}
    
    red_prediction.train()
    red_dynamics.train()
    blue_hidden_state.train()
    blue_prediction.train()
    blue_dynamics.train()
    
    red_input, blue_input = create_running_observation_from_dict(history_depth, trajectory)
 
 
  
    r_hidden_state = red_hidden_state(red_input)
    b_hidden_state = blue_hidden_state(blue_input)
    
    trajectory_keys_as_ints = [int(x) for x in list(trajectory.keys())]
    start_time_step = min(trajectory_keys_as_ints)
 
    
    

    for t in range(0, (unroll_depth)*2):

        adjusted_t = t // 2 + start_time_step + history_depth - 1
       


         
        
        if (t)%2 == 0:

    
            
            red_predicted_policy_logits, red_predicted_v_logits = red_prediction(r_hidden_state)

            # red_predicted_policy_logits = soft_temp_max(red_predicted_policy_logits)
            # red_predicted_v_probs = soft_temp_max(red_predicted_v_probs, temp=1)
            # red_predicted_value = categorical_prediction(red_predicted_v_probs, value_support_set)
            blue_predicted_policy_logits, blue_predicted_v_logits = blue_prediction(b_hidden_state)
            
            # blue_predicted_v_prob = soft_temp_max(blue_predicted_v_prob, temp=1)
            # blue_predicted_policy_logits = soft_temp_max(blue_predicted_policy_logits)
            # blue_predicted_value = categorical_prediction(blue_predicted_v_probs, value_support_set)

            
            b_act_t = torch.tensor(trajectory[str(adjusted_t)]['blue']['action']).view(1, -1)
            r_act_t = torch.tensor(trajectory[str(adjusted_t)]['red']['action']).view(1, -1)
            
            
            
            
            red_dyn_input = torch.cat((r_hidden_state, r_act_t), dim=1)
            blue_dyn_input = torch.cat((b_hidden_state, b_act_t), dim=1)
            
            b_hidden_state, red_predicted_r_logits = red_dynamics(red_dyn_input)
            # red_predicted_r_prob = soft_temp_max(red_predicted_r_prob, temp=1)
            r_hidden_state, blue_predicted_r_logits = blue_dynamics(blue_dyn_input)
            # blue_predicted_r_prob = soft_temp_max(blue_predicted_r_prob, temp=1)
            # red_predicted_reward = categorical_prediction(red_predicted_r_prob, reward_support_set)
            # blue_predicted_reward = categorical_prediction(blue_predicted_r_prob, reward_support_set)
            
          
            
            red_start_outputs.setdefault(adjusted_t, {})
            blue_start_outputs.setdefault(adjusted_t, {})
            
            
            
            
            red_start_outputs[adjusted_t].update({'red_rewards': red_predicted_r_logits, 'red_values': red_predicted_v_logits, 'red_policies': red_predicted_policy_logits, 'red_action': r_act_t})
            blue_start_outputs[adjusted_t].update({'blue_rewards': blue_predicted_r_logits, 'blue_values': blue_predicted_v_logits, 'blue_policies': blue_predicted_policy_logits, 'blue_action': b_act_t})
            
            
            
        else:
            
        

            b_act_t = torch.tensor(trajectory[str(adjusted_t+1)]['blue']['action']).view(1, -1)
            r_act_t = torch.tensor(trajectory[str(adjusted_t)]['red']['action']).view(1, -1)
            
        
            
            blue_predicted_policy_logits, blue_predicted_v_logits = blue_prediction(b_hidden_state)
            # blue_predicted_v_prob = soft_temp_max(blue_predicted_v_prob, temp=1)
            # blue_predicted_policy_logits = soft_temp_max(blue_predicted_policy_logits)
            # blue_predicted_value = categorical_prediction(blue_predicted_v_prob, value_support_set)

            red_predicted_policy_logits, red_predicted_v_logits = red_prediction(r_hidden_state)
            # red_predicted_v_prob = soft_temp_max(red_predicted_v_prob, temp=1)
            # red_predicted_policy_logits = soft_temp_max(red_predicted_policy_logits)
            # red_predicted_value = categorical_prediction(red_predicted_v_prob, value_support_set)
    
            red_dyn_input = torch.cat((r_hidden_state, r_act_t), dim=1)
            blue_dyn_input = torch.cat((b_hidden_state, b_act_t), dim=1)
            

            # b_hidden_state, red_predicted_r_prob = red_dynamics(red_dyn_input)
            # # red_predicted_reward = categorical_prediction(red_predicted_r_prob, reward_support_set)

            # r_hidden_state, blue_predicted_r_probs = blue_dynamics(blue_dyn_input)
            # # blue_predicted_reward = categorical_prediction(blue_predicted_r_probs, reward_support_set)
          
            b_hidden_state, red_predicted_r_logits = red_dynamics(red_dyn_input)
            # red_predicted_r_prob = soft_temp_max(red_predicted_r_prob, temp=1)
            r_hidden_state, blue_predicted_r_logits = blue_dynamics(blue_dyn_input)
            # blue_predicted_r_prob = soft_temp_max(blue_predicted_r_prob, temp=1)

            
            red_start_outputs.setdefault(adjusted_t+1, {})
            blue_start_outputs.setdefault(adjusted_t, {})
            
            red_start_outputs[adjusted_t+1].update({'blue_rewards': blue_predicted_r_logits, 'blue_values': blue_predicted_v_logits, 'blue_policies': blue_predicted_policy_logits, 'blue_action': b_act_t})
            blue_start_outputs[adjusted_t].update({'red_rewards': red_predicted_r_logits, 'red_values': red_predicted_v_logits, 'red_policies': red_predicted_policy_logits, 'red_action': r_act_t})
            

 
    return red_start_outputs, blue_start_outputs

def train_modelsv3(red_dynamics, red_prediction, red_hidden_state,
                 blue_dynamics, blue_prediction, blue_hidden_state,
                 training_trajectories, training_weights, gamma = 0.99, mini_batch_size = 200):


    path_to_optimizers = 'Optimizers_puct2_self_play_adam_PER'
    optimizer = load_latest_optimizers(path_to_optimizers=path_to_optimizers, red_dynamics=red_dynamics, red_prediction=red_prediction, red_hidden_state=red_hidden_state, blue_dynamics=blue_dynamics, blue_prediction=blue_prediction, blue_hidden_state=blue_hidden_state)

    
    
    # value_loss_fn = nn.MSELoss()
    # policy_loss_fn = nn.CrossEntropyLoss()
    # reward_loss_fn = nn.MSELoss()

    unroll_depth = 5
    boostrap_depth = 10
    history_depth = 1
    progress = 0
    total_loss = 0

    def scale_gradients(module, grad_input, grad_output):
        scaled_grad_input = tuple(grad / 2 for grad in grad_input)  # Scale by 1/2
        return scaled_grad_input

    # Register the gradient scaling hook for the dynamics function
    blue_hook_handle = blue_dynamics.register_full_backward_hook(scale_gradients)
    red_hook_handel = red_dynamics.register_full_backward_hook(scale_gradients)

    
    

    total_value_loss, total_policy_loss, total_reward_loss = 0, 0, 0
    total_l2_loss = 0

   
    for trajectory, weight  in zip(training_trajectories, training_weights):

        
        

        (red_start_outputs, blue_start_outputs) = get_rew_pols_vals(trajectory,
                                             red_hidden_state,
                                             red_prediction,
                                             red_dynamics,
                                             blue_hidden_state,
                                             blue_prediction,
                                             blue_dynamics)
        
        # if progress == 200:
        #     print(trajectory)
        #     print('-'*10)
        #     print(red_start_outputs)
            
      
     


        trajectory_keys_as_ints = [int(x) for x in list(trajectory.keys())]
        start_time_step = min(trajectory_keys_as_ints)

        first_time_step_pred = start_time_step + history_depth - 1
        target_values = get_value_targets(first_time_step_pred, boostrap_depth, gamma, unroll_depth, trajectory)

    
        

    
        
        reward_loss, policy_loss, value_loss = get_losses(history_depth, unroll_depth, start_time_step, red_start_outputs, blue_start_outputs, trajectory, target_values)
       
        # total_loss += (reward_loss + policy_loss + value_loss)

        total_reward_loss += reward_loss/mini_batch_size
        total_policy_loss += policy_loss/mini_batch_size
        total_value_loss += value_loss/mini_batch_size
        
        # print(reward_loss, policy_loss, value_loss)
        


        progress +=1

        
     
        if progress % mini_batch_size == 0:
            total_loss = total_reward_loss + total_policy_loss + total_value_loss
            optimizer.zero_grad()
            total_loss.backward()
            optimizer.step()
            print('-'*76)
            print(f'Policy loss: {total_policy_loss}')
            print(f'Reward loss: {total_reward_loss}')
            print(f'Value loss: {total_value_loss}')
            print(f'L2 loss: {total_l2_loss}')
            print(f'count: {progress}')
            print('-'*76)
            total_value_loss, total_policy_loss, total_reward_loss = 0, 0, 0
            total_l2_loss = 0
            total_loss = 0

        # sleep(3)
    blue_hook_handle.remove()
    red_hook_handel.remove()

    save_optimizers(optimizer, path_to_optimizers)

    return red_dynamics, red_prediction, red_hidden_state, blue_dynamics, blue_prediction, blue_hidden_state

def get_value_targets(start_time_step, boostrap_depth, gamma, unroll_depth ,trajectory):
    
    targets = {t:{'red': {'value': None}, 'blue': {'value': None}} for t in range(start_time_step, start_time_step + unroll_depth+1)}
    
    for t in range(start_time_step, start_time_step + unroll_depth+1):
        
        targets[t]['red']['value'] = copy.copy(trajectory[str(t)]['red']['target_value'])
        targets[t]['blue']['value'] = copy.copy(trajectory[str(t)]['blue']['target_value'])

    return targets
    
def create_running_observation_from_dict(histroy_depth, trajectory):
    def get_inputv2(trajectory, histroy_depth, turn):
        
        trajectory_keys_as_ints = [int(key) for key in trajectory.keys()]   
        start_time_step = min(trajectory_keys_as_ints)
        
        
        h_depth_obs = [trajectory[str(int(start_time_step)+t)][turn]['observation'] for t in range(histroy_depth)]
        h_depth_act = [trajectory[str(int(start_time_step)+t)][turn]['action'] for t in range(histroy_depth-1)]
        

        h_depth_obs = torch.tensor(h_depth_obs, dtype=torch.float32).view(1, -1)
        h_depth_act = torch.tensor(h_depth_act, dtype=torch.float32).view(1, -1)

        input_from_env = torch.cat((h_depth_obs, h_depth_act), dim=1).view(1, -1)
        
       
            
        
        return input_from_env 

    red_input_from_env = get_inputv2(trajectory, histroy_depth ,'red')
    blue_input_from_env = get_inputv2(trajectory, histroy_depth, 'blue')

    return red_input_from_env, blue_input_from_env

def get_losses(history_depth, unroll_depth, start_time_step, red_start_outputs, blue_start_outputs, trajectory, target_values):
    
    '''
    Get the losses
    
    Parameters:
    -----------
    history_depth: int
        The history depth
    unroll_depth: int
        The unroll depth
    start_time_step: int
        The start time step
    red_start_outputs: dict
        The red start outputs
    blue_start_outputs: dict
        The blue start outputs
    trajectory: dict
        The trajectory
    target_values: dict
        The target values
    reward_loss_fn: nn.Module
        The reward loss function
    policy_loss_fn: nn.Module
        The policy loss function
    value_loss_fn: nn.Module
        The value loss function
        
    Returns:
    --------
    total_reward_loss: float
        The total reward loss
    total_policy_loss: float
        The total policy loss
    total_value_loss: float
        The total value loss
    
    '''
    total_reward_loss = 0
    total_policy_loss = 0
    total_value_loss = 0
    
    for t in range(history_depth-1, history_depth + unroll_depth-1):
      
        red_reward_loss = (kl_div_loss_support(red_start_outputs[start_time_step+t]['red_rewards'], trajectory[str(start_time_step + t)]['red']['reward'], reward_support_set) +
                            kl_div_loss_support(blue_start_outputs[start_time_step+t]['red_rewards'], trajectory[str(start_time_step + t)]['red']['reward'], reward_support_set))
        
        blue_reward_loss = (kl_div_loss_support(blue_start_outputs[start_time_step+t]['blue_rewards'],  trajectory[str(start_time_step + t)]['blue']['reward'], reward_support_set) +
                            kl_div_loss_support(red_start_outputs[start_time_step+t+1]['blue_rewards'],  trajectory[str(start_time_step + t+1)]['blue']['reward'], reward_support_set))
        
        total_reward_loss += (red_reward_loss + blue_reward_loss)/10
        
        
        red_policy_loss = (kl_div_loss(red_start_outputs[start_time_step+t]['red_policies'], torch.tensor(trajectory[str(start_time_step + t)]['red']['policy']).view(1, -1)) +
                            kl_div_loss(blue_start_outputs[start_time_step+t]['red_policies'], torch.tensor(trajectory[str(start_time_step + t)]['red']['policy']).view(1, -1)))
        
        blue_policy_loss = (kl_div_loss(blue_start_outputs[start_time_step+t]['blue_policies'], torch.tensor(trajectory[str(start_time_step + t)]['blue']['policy']).view(1, -1)) +
                            kl_div_loss(red_start_outputs[start_time_step+t+1]['blue_policies'], torch.tensor(trajectory[str(start_time_step + t+1)]['blue']['policy']).view(1, -1)))
        

        
        total_policy_loss += (red_policy_loss + blue_policy_loss)/10
                    
        
        red_start_red_value_loss = kl_div_loss_support(red_start_outputs[start_time_step+t]['red_values'], target_values[start_time_step + t]['red']['value'], value_support_set) 
        
        red_start_blue_value_loss = kl_div_loss_support(red_start_outputs[start_time_step+t+1]['blue_values'], target_values[start_time_step + t+1]['blue']['value'], value_support_set)
        
        blue_start_blue_value_loss = kl_div_loss_support(blue_start_outputs[start_time_step+t]['blue_values'], target_values[start_time_step + t]['blue']['value'], value_support_set)

        
        blue_start_red_value_loss = kl_div_loss_support(blue_start_outputs[start_time_step+t]['red_values'], target_values[start_time_step + t]['red']['value'], value_support_set)
        
        total_value_loss += (red_start_red_value_loss + red_start_blue_value_loss + blue_start_blue_value_loss + blue_start_red_value_loss)/10
 
    return total_reward_loss, total_policy_loss, total_value_loss