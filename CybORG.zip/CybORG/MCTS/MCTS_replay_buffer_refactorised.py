import os
import json
import numpy as np
import torch
from copy import deepcopy, copy
import time
from tqdm import tqdm
from MCTS.MCTS_value_wrangeling import sftm_categorical_to_value, soft_temp_max
import matplotlib.pyplot as plt

class ReplayBuffer:
    def __init__(self, path_to_training_data: str, blue_hidden_state, blue_prediction, red_hidden_state, red_prediction) -> None:
        print('__init__')
        self.max_steps = 100
        self.max_num_series = 40
        self.gamma = 0.99
        self.bootstrap_depth = 10
        self.unroll_depth = 5

        self.red_sleep_list = np.zeros(68, dtype=int)
        self.blue_sleep_list = np.zeros(66, dtype=int)
        self.red_sleep_list[0] = 1
        self.blue_sleep_list[0] = 1

        self.replay_buffer = self._initialize_data_input(path_to_training_data)
        self.buffer_size = len(self.replay_buffer)
        self.current_buffer_num_series = self.buffer_size // 12
        self.total_buffer_volume = self.max_steps * 12 * self.current_buffer_num_series
        self.first_episode_key = min(self.replay_buffer.keys(), default=0)

        self.blue_hidden_state = blue_hidden_state
        self.blue_prediction_net = blue_prediction
        self.red_hidden_state = red_hidden_state
        self.red_prediction_net = red_prediction

        self.value_step = 1
        self.value_support_set = np.arange(0, 100 + self.value_step, self.value_step)

        self.is_predicted_values_up_to_date = False
        self._update_all_values_in_buffer()
        self._get_current_target_and_pred_value_array()

    def red_prediction(self, state):
        ''' get the prediction for the red agent
        
        Parameters:
        -----------
        state: torch.tensor
            The hidden state representation of the environment
            
        Returns:
        --------
        torch.tensor
            The prediction value for the red agent's expected returns from the state
            
        '''
    
        p,v = self.red_prediction_net(state)
        p, v = soft_temp_max(p), soft_temp_max(v)
        v = sftm_categorical_to_value(v, self.value_support_set)
        return p, v
    
    def blue_prediction(self, state):
        ''' get the prediction for the red agent
        
        Parameters:
        -----------
        state: torch.tensor
            The hidden state representation of the environment
            
        Returns:
        --------
        torch.tensor
            The prediction value for the red agent's expected returns from the state
            
        '''
    
        p,v = self.blue_prediction_net(state)
        p, v = soft_temp_max(p), soft_temp_max(v)
        v = sftm_categorical_to_value(v, self.value_support_set)
        return p, v

    def _initialize_data_input(self, path_to_training_data):
        print('_initialize_data_input')
        ordered_data_paths = self._get_old_data_file_names(path_to_training_data)
        if not ordered_data_paths:
            return {}

        init_replay_buffer = {}
        for i, data in enumerate(ordered_data_paths[:self.max_num_series]):
            data_name = os.listdir(f'{path_to_training_data}/{data}')[0]
            path_to_data = f'{path_to_training_data}/{data}/{data_name}'
            data = json.load(open(path_to_data))
            for key, value in data.items():
                init_replay_buffer[str(int(key) + i * 12 - 1)] = value

        return init_replay_buffer

    def _get_old_data_file_names(self, path_to_training_data):
        print('_get_old_data_file_names')
        return sorted([x for x in os.listdir(path_to_training_data) if x != '.DS_Store'], reverse=True)

    def _convert_index_to_episode_time_step(self, index):
        key = index//self.max_steps
        time_step = index - key*self.max_steps

        key +=  int(self.first_episode_key)
        return(key, time_step)
    
    def _convert_episode_time_step_to_index(self, key, time_step):

        index = (int(key)-int(self.first_episode_key))*self.max_steps + int(time_step)
        return(index)

    def fifo_update(self, new_data):
        print('fifo_update')
        if not self.replay_buffer:
            self.replay_buffer = new_data
            self.first_episode_key = 0
        else:
            latest_episode_number = max(map(int, self.replay_buffer.keys()))
            replay_buffer_keys_as_ints = list(map(int, self.replay_buffer.keys()))

            for key, value in new_data.items():
                if len(self.replay_buffer) >= self.max_num_series:
                    min_key = str(min(replay_buffer_keys_as_ints))
                    del self.replay_buffer[min_key]
                    replay_buffer_keys_as_ints.remove(min(replay_buffer_keys_as_ints))

                self.replay_buffer[str(int(key) + latest_episode_number)] = value
                replay_buffer_keys_as_ints.append(int(key) + latest_episode_number)

            self.first_episode_key = str(min(replay_buffer_keys_as_ints))

        self.is_predicted_values_up_to_date = False
        self.buffer_size = len(self.replay_buffer)
        self.current_buffer_num_series = self.buffer_size // 12
        self.total_buffer_volume = self.max_steps * 12 * self.current_buffer_num_series

    def _update_target_values_in_buffer(self):
        print('_update_target_values_in_buffer')
        for key, value in self.replay_buffer.items():
            time_steps = np.array(list(map(int, value.keys())))
            for t in time_steps:
       
                if t + self.bootstrap_depth + self.unroll_depth >= self.max_steps:
                    value_red = copy(self.replay_buffer[key][str(t)]['red']['value'])
                    value_blue = copy(self.replay_buffer[key][str(t)]['blue']['value'])

                else:
                    
                    value_red = value[str(t+self.bootstrap_depth)]['red']['value'] * self.gamma**self.bootstrap_depth
                    value_blue = value[str(t+self.bootstrap_depth)]['blue']['value'] * self.gamma**self.bootstrap_depth



         
                    for i in range(0, self.bootstrap_depth):

        
                        value_red += value[str(t+i)]['red']['reward'] * self.gamma**i
                        value_blue += value[str(t+i)]['blue']['reward'] * self.gamma**i




                self.replay_buffer[key][str(t)]['red']['target_value'] = value_red
                self.replay_buffer[key][str(t)]['blue']['target_value'] = value_blue

                

           


    def _update_predicted_values_in_buffer(self):
        print('_update_predicted_values_in_buffer')
        self.red_prediction_net.train()
        self.blue_prediction_net.train()
        self.red_hidden_state.train()
        self.blue_hidden_state.train()
        
        for key, value in tqdm(self.replay_buffer.items()):
        # for key, value in (self.replay_buffer.items()):
   
            time_steps = np.array(list(map(int, value.keys())))
            observations = []
       
            for t in time_steps:
                observation_start = t 
                trajectory = {
                    str(i): (value['0'] if i < 0 else value.get(str(i), {}))
                    for i in range(observation_start, observation_start+1)
                }
                observations.append(self._create_running_observation_from_dict(1, trajectory))

            red_inputs, blue_inputs = zip(*observations)


            with torch.no_grad():
                for t,(red_inputs, blue_inputs) in enumerate(zip(red_inputs, blue_inputs)):
         
                    _, predicted_red_values = self.red_prediction(self.red_hidden_state(red_inputs))
                    _, predicted_blue_values = self.blue_prediction(self.blue_hidden_state(blue_inputs))
            #     _, predicted_red_values = self.red_prediction(self.red_hidden_state(red_inputs))
            #     _, predicted_blue_values = self.blue_prediction(self.blue_hidden_state(blue_inputs))
     
                    value[str(t)]['red']['value'] = predicted_red_values
                    value[str(t)]['blue']['value'] = predicted_blue_values

            # time.sleep(10)

    def _create_running_observation_from_dict(self, history_depth, trajectory):
 
        def get_input(trajectory, turn):
            trajectory_keys_as_int = [int(x) for x in list(trajectory.keys())]
            start_time_step = min(trajectory_keys_as_int)
            h_depth_obs = np.array([trajectory[str(start_time_step)][turn]['observation'] for i in range(history_depth)])
            # h_depth_act = np.concatenate([trajectory[str(start_time_step+i)][turn]['action'] for i in range(history_depth - 1)])
            return torch.tensor(h_depth_obs, dtype=torch.float32).view(1, -1)

        red_input = get_input(trajectory, 'red')
        blue_input = get_input(trajectory, 'blue')
        return red_input, blue_input

    def _get_current_target_and_pred_value_array(self):
        print('_get_current_target_and_pred_value_array')
        if not self.is_predicted_values_up_to_date:
            self._update_all_values_in_buffer()

    
        red_values, red_target_values, blue_values, blue_target_values = np.zeros(self.total_buffer_volume), np.zeros(self.total_buffer_volume), np.zeros(self.total_buffer_volume), np.zeros(self.total_buffer_volume)

        for key, value in self.replay_buffer.items():
            for t, info in value.items():
                index = self._convert_episode_time_step_to_index(key, t)
                red_values[index] = info['red']['value']
                red_target_values[index] = info['red']['target_value']
                blue_values[index] = info['blue']['value']
                blue_target_values[index] = info['blue']['target_value']
                

        self.red_values = red_values
        self.red_target_values = red_target_values
        self.blue_values = blue_values
        self.blue_target_values = blue_target_values


    def _update_all_values_in_buffer(self):
        print('_update_all_values_in_buffer')
        self._update_predicted_values_in_buffer()
        self._update_target_values_in_buffer()
        self.is_predicted_values_up_to_date = True

    def get_probs(self):
        print('get_probs')
        if not self.is_predicted_values_up_to_date:
            self._update_all_values_in_buffer()
            self._get_current_target_and_pred_value_array()

        red_td_errors = np.abs(self.red_target_values - self.red_values)
        blue_td_errors = np.abs(self.blue_target_values - self.blue_values)

        print('red_td_errors_max:', max(red_td_errors))
        print('blue_td_errors_max:', max(blue_td_errors))
        print('red_td_errors_mean:', np.mean(red_td_errors))
        print('blue_td_errors_mean:', np.mean(blue_td_errors))

        red_probs = red_td_errors / (np.sum(red_td_errors) + 1e-5)
        blue_probs = blue_td_errors / (np.sum(blue_td_errors) + 1e-5)




        return red_probs, blue_probs


    def get_uniform_probs(self):
        a = np.ones(100)



        a[86::]=0

        probs = np.tile(a, 480)
        probs /= np.sum(probs)

        red_probs = probs.copy()
        blue_probs = probs.copy()

        return red_probs, blue_probs



    def get_uniform_random_sample(self, batch_size):
        print('uniform_random_sample')
        print('get_batch')
        if self.current_buffer_num_series < self.max_num_series:
            return None, None

      
        red_probs, blue_probs = self.get_uniform_probs()
        red_batch_size = batch_size // 2
        blue_batch_size = batch_size - red_batch_size

        red_samples = torch.multinomial(torch.tensor(red_probs, dtype=torch.float32), red_batch_size)
        blue_samples = torch.multinomial(torch.tensor(blue_probs, dtype=torch.float32), blue_batch_size)

        trajectories, weights = [], []

        for red_index, blue_index in zip(red_samples, blue_samples):
            red_key, red_time_step = self._convert_index_to_episode_time_step(red_index.item())
            blue_key, blue_time_step = self._convert_index_to_episode_time_step(blue_index.item())

            def extract_trajectory(key, time_step):
                return {
                    str(i): (self.replay_buffer[str(key)]['0'] if i < 0 else self.replay_buffer[str(key)].get(str(i), {}))
                    for i in range(time_step, time_step + 16)
                }

            trajectories.append(extract_trajectory(red_key, red_time_step))
            trajectories.append(extract_trajectory(blue_key, blue_time_step))

            red_weight = 2 / (self.total_buffer_volume * red_probs[red_index])
            blue_weight = 2 / (self.total_buffer_volume * blue_probs[blue_index])
            weights.extend([1, 1])

        weights = torch.tensor(weights, dtype=torch.float32)
        # weights /= torch.max(weights)

        print(min(red_probs), max(red_probs))
        print(min(blue_probs), max(blue_probs))
        

        return trajectories, weights





    def get_batch(self, batch_size):
        print('get_batch')
        if self.current_buffer_num_series < self.max_num_series:
            return None, None

        red_probs_picked = []
        blue_probs_picked = []
        red_probs, blue_probs = self.get_probs()
        red_batch_size = batch_size // 2
        blue_batch_size = batch_size - red_batch_size

        red_samples = torch.multinomial(torch.tensor(red_probs, dtype=torch.float32), red_batch_size)
        blue_samples = torch.multinomial(torch.tensor(blue_probs, dtype=torch.float32), blue_batch_size)

        trajectories, weights = [], []

        for red_index, blue_index in zip(red_samples, blue_samples):
            red_key, red_time_step = self._convert_index_to_episode_time_step(red_index.item())
            blue_key, blue_time_step = self._convert_index_to_episode_time_step(blue_index.item())

            def extract_trajectory(key, time_step):
                return {
                    str(i): (self.replay_buffer[str(key)]['0'] if i < 0 else self.replay_buffer[str(key)].get(str(i), {}))
                    for i in range(time_step, time_step + 16)
                }

            trajectories.append(extract_trajectory(red_key, red_time_step))
            trajectories.append(extract_trajectory(blue_key, blue_time_step))

            red_weight = 2 / (self.total_buffer_volume * red_probs[red_index])
            blue_weight = 2 / (self.total_buffer_volume * blue_probs[blue_index])
            weights.extend([red_weight, blue_weight])

            red_probs_picked.append(red_probs[red_index])
            blue_probs_picked.append(blue_probs[blue_index])

        weights = torch.tensor(weights, dtype=torch.float32)
        # weights /= torch.max(weights)


        print(min(red_probs_picked), max(red_probs_picked))
        print(min(blue_probs_picked), max(blue_probs_picked))
        # plt.hist(weights, bins=100)
        # plt.show()

        return trajectories, weights
    
    def update_models(self, blue_hidden_state, blue_prediction, red_hidden_state, red_prediction):
        print('update_models')
        self.blue_hidden_state = blue_hidden_state
        self.red_hidden_state = red_hidden_state
        self.blue_prediction_net = blue_prediction
        self.red_prediction_net = red_prediction
        self.is_predicted_values_up_to_date == False
