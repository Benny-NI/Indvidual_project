import math
import inspect
from copy import deepcopy

from tkinter import NO
from prettytable import PrettyTable # type: ignore
import numpy as np # type: ignore

from CybORG.Agents.Wrappers.BaseWrapper import BaseWrapper

from CybORG import CybORG
from CybORG.Simulator.Actions.AbstractActions.Impact import Impact # type: ignore
from CybORG.Simulator.Actions.AbstractActions.Restore import Restore
from CybORG.Shared import Observation, Results
from CybORG.Simulator.Actions.Action import Sleep, InvalidAction


class SelfPlayWrapperv3(BaseWrapper):
    def __init__(self, env: CybORG):
            super().__init__(env)
            self.env = env
            self.reward_scale_factor = 1/16.8
            self.scanned_ips = set()

            # Infomation related to what the red agent can infer
            self.red_info = {}
            self.red_known_subnets = set()
            # Used for providing unique ids to unkown hosts
            self.red_id_tracker = -1

            self.red_last_action_success = None

            # Infomation for the blue agent
            self.baseline = None
            self.blue_info = {}
            self.blue_blue_info = {}

            self.red_action_signature = {}
            self.blue_action_signature = {}

            self.red_actions_excuted = [Sleep()]
            self.blue_actions_excuted = [Sleep()]

            # self.blue_complete_action_space = self.get_blue_actions()


            self.blue_reaction_to_red = {}
            self.blue_obs_blue_action = {}

            self.red_latest_avalibale_actions = []
            self.blue_latest_avalibale_actions = []

    def reset(self):

        # Infomation related to what the red agent can infer
        self.red_info = {}
        self.red_known_subnets = set()
        # Used for providing unique ids to unkown hosts
        self.red_id_tracker = -1

        self.red_last_action_success = None

        # Infomation for the blue agent
        self.baseline = {}





        # Given that there is a seed then we can use reset twice and still
        # get a valid discription of the same simulation; hence:
        # red_reset_result = self.env.reset('Red')   



        # red_reset_result.observation = self.red_intial_obs_process(red_reset_result.observation) 


        
        
        blue_reset_result = self.env.reset('Blue')

        


        self.blue_inital_obs_process(blue_reset_result.observation)


        blue_reset_result.observation = self.blue_observation_change(blue_reset_result.observation, baseline=True)
        blue_reset_result.action_space = self.blue_action_space_change(blue_reset_result.action_space)

        red_reset_result = Results()
        red_reset_result.observation = self.red_intial_obs_process(self.env.environment_controller.observation['Red'].data)
        red_reset_result.action_space = self.red_action_space_change(self.env.environment_controller.agent_interfaces['Red'].action_space.get_action_space())

        self.red_complete_action_space = deepcopy(red_reset_result.action_space)
        
        self.blue_complete_action_space = deepcopy(blue_reset_result.action_space)



        return(red_reset_result, blue_reset_result)
    
    def step(self, agent=None, action=None):
        result = self.env.step(agent, action)

        obs = result.observation
        action = self.validity_of_action_checking(agent, action)
        if agent == 'Blue':
            self.blue_actions_excuted.append(action)
            new_obs = deepcopy(self.blue_reaction_to_red)
            new_obs.update(obs)
            obs = self.blue_observation_change(new_obs)
            self.blue_latest_avalibale_actions = result.action_space

            reward = self.get_rewards()[1]

        elif agent == 'Red':
            self.red_actions_excuted.append(action)
            self.blue_reaction_to_red = deepcopy(self.env.environment_controller.observation['Blue'].data)
            obs = self.red_observation_change(obs)
            self.red_latest_avalibale_actions = result.action_space
            reward = self.get_rewards()[0]
            

        result.observation = obs
        result.reward = reward
        
        self._update_scanned()

        return result

    
    def stepv2(self, agent=None, action=None):
        result = self.env.step(agent, action)

        obs = result.observation
        action = self.validity_of_action_checking(agent, action)
        if agent == 'Red':
            self.red_actions_excuted.append(action)
            # red_new_observation = deepcopy(self.env.environment_controller.observation['Red'].data)
            
            # blue_new_observation = deepcopy(self.env.environment_controller.observation['Blue'].data)
            red_new_observation = obs
            blue_new_observation = self.env.get_observation('Blue')
            blue_new_observation.update(self.blue_obs_blue_action)
            red_obs = self.red_observation_change(red_new_observation)
            blue_obs = self.blue_observation_change(blue_new_observation)

            self.red_latest_avalibale_actions = result.action_space
         

        elif agent == 'Blue':
            self.blue_actions_excuted.append(action)
            # red_new_observation = deepcopy(self.env.environment_controller.observation['Red'].data)
            # blue_new_observation = deepcopy(self.env.environment_controller.observation['Blue'].data)
            red_new_observation = self.env.get_observation('Red')
            blue_new_observation = obs
            self.blue_obs_blue_action = deepcopy(blue_new_observation)

            red_obs = self.red_observation_change(red_new_observation)
            blue_obs = self.blue_observation_change(blue_new_observation)

            self.blue_latest_avalibale_actions = result.action_space



        red_reward, blue_reward = self.get_rewards()

        return red_obs, blue_obs, red_new_observation, blue_new_observation, red_reward, blue_reward

             
    

    def step_with_raw_outputs(self, agent=None, action=None):
        result = self.env.step(agent, action)
    
        obs = result.observation
        action = self.validity_of_action_checking(agent, action)
        if agent == 'Blue':
            self.blue_actions_excuted.append(action)
            new_obs = deepcopy(self.blue_reaction_to_red)
            new_obs.update(obs)
            # obs = self.blue_observation_change(new_obs)
            obs = new_obs
            self.blue_latest_avalibale_actions = result.action_space

            reward = self.get_rewards()[1]

        elif agent == 'Red':
            self.red_actions_excuted.append(action)
            self.blue_reaction_to_red = deepcopy(self.env.environment_controller.observation['Blue'].data)
            # obs = self.red_observation_change(obs)
            self.red_latest_avalibale_actions = result.action_space
            reward = self.get_rewards()[0]

        result.observation = obs
        result.reward = reward
        
        self._update_scanned() 

        return result
    
    def red_observation_change(self, observation):
        obs = observation if type(observation) == dict else observation.data
        obs = deepcopy(observation)
        self.red_last_action_success = obs['success']

        
        if self.red_last_action_success == True:

            self.update_red_info(obs)

        obs = self.create_red_vector()

        return obs
    
    def blue_observation_change(self,observation,baseline=False):
        obs = observation if type(observation) == dict else observation.data
        obs = deepcopy(obs)
        success = obs['success']

        self.blue_process_last_action()
        anomaly_obs = self.blue_detect_anomalies(obs) if not baseline else obs
        del obs['success']

        # TODO check what info is for baseline
        info = self.blue_process_anomalies(anomaly_obs)
        if baseline:
            for host in info:
                info[host][-2] = 'None'
                info[host][-1] = 'No'
                self.blue_blue_info[host][-1] = 'No'

        self.blue_info = info

        return(self.create_blue_vector(success))
      
    def update_red_info(self, obs):
        action = self.get_last_action(agent='Red')
        name = action.__class__.__name__
        if name == 'DiscoverRemoteSystems':
            self.red_add_ips(obs)
        elif name == 'DiscoverNetworkServices':

            ip = str(obs.popitem()[1]['Interface'][0]['IP Address'])
            self.red_info[ip][3] = True
        elif name == 'ExploitRemoteService':
            self.red_process_exploit(obs)
        elif name == 'PrivilegeEscalate':
            hostname = action.hostname
            self.red_process_priv_esc(obs, hostname)

    def create_red_vector(self, num_hosts=13):
        table = self.red_create_red_table()._rows

        # Compute required length of vector based on number of hosts
        padding = num_hosts - len(table)
        id_length = math.ceil(math.log2(num_hosts))

        success_value = int(self.red_last_action_success.value) if self.red_last_action_success.value < 2 else -1
        proto_vector = [success_value]
        for row in table:
            # Scanned
            proto_vector.append(int(row[3]))

            # Access
            access = row[4]
            if access == 'None':
                value = [0, 0]
            elif access == 'User':
                value = [1, 0]
            elif access == 'Privileged':
                value = [0, 1]
            else:
                raise ValueError('Table had invalid Access Level')
            proto_vector.extend(value)

        proto_vector.extend(padding * 3 * [-1])

        
        return np.array(proto_vector)

    def create_blue_vector(self, success):
        table = self.blue_create_blue_table(success)._rows

        proto_vector = []
        for row in table:
            # Activity
            activity = row[3]
            if activity == 'None':
                value = [0,0]
            elif activity == 'Scan':
                value = [1,0]
            elif activity == 'Exploit':
                value = [1,1]
            else:
                raise ValueError('Table had invalid Access Level')
            proto_vector.extend(value)

            # Compromised
            compromised = row[4]
            if compromised == 'No':
                value = [0, 0]
            elif compromised == 'Unknown':
                value = [1, 0]
            elif compromised == 'User':
                value = [0,1]
            elif compromised == 'Privileged':
                value = [1,1]
            else:
                raise ValueError('Table had invalid Access Level')
            proto_vector.extend(value)

        return np.array(proto_vector)

    def red_intial_obs_process(self, obs):
        self.red_last_action_success = obs['success']

        for hostid in obs:
            if hostid == 'success':
                continue
            host = obs[hostid]
            interface = host['Interface'][0]
            subnet = interface['Subnet']
            self.red_known_subnets.add(subnet)
            ip = str(interface['IP Address'])
            hostname = host['System info']['Hostname']
            self.red_info[ip] = [str(subnet), str(ip), hostname, False, 'Privileged']

        
        return(self.create_red_vector())

    def blue_inital_obs_process(self, obs):
        obs = obs.copy()
        self.baseline = obs
        del self.baseline['success']
        for hostid in obs:
            if hostid == 'success':
                continue
            host = obs[hostid]
            interface = host['Interface'][0]
            subnet = interface['Subnet']
            ip = str(interface['IP Address'])
            hostname = host['System info']['Hostname']
            self.blue_blue_info[hostname] = [str(subnet),str(ip),hostname, 'None','No']
        return self.blue_blue_info

    def blue_process_anomalies(self,anomaly_dict):
        info = deepcopy(self.blue_blue_info)
        for hostid, host_anomalies in anomaly_dict.items():
            assert len(host_anomalies) > 0
            if 'Processes' in host_anomalies:
                connection_type = self.blue_interpret_connections(host_anomalies['Processes'])
                info[hostid][-2] = connection_type
                if connection_type == 'Exploit':
                    info[hostid][-1] = 'User'
                    self.blue_blue_info[hostid][-1] = 'User'
            if 'Files' in host_anomalies:
                malware = [f['Density'] >= 0.9 for f in host_anomalies['Files']]
                if any(malware):
                    info[hostid][-1] = 'Privileged'
                    self.blue_blue_info[hostid][-1] = 'Privileged'

        return info

    def blue_process_last_action(self):
        action = self.get_last_action(agent='Blue')
        if action is not None:
            name = action.__class__.__name__
            hostname = action.get_params()['hostname'] if name in ('Restore','Remove') else None

            if name == 'Restore':
                self.blue_blue_info[hostname][-1] = 'No'
            elif name == 'Remove':
                compromised = self.blue_blue_info[hostname][-1]
                if compromised != 'No':
                    self.blue_blue_info[hostname][-1] = 'Unknown'

    def blue_detect_anomalies(self,obs):
        if self.baseline is None:
            raise TypeError('BlueTableWrapper was unable to establish baseline. This usually means the environment was not reset before calling the step method.')

        anomaly_dict = {}

        for hostid,host in obs.items():
            if hostid == 'success':
                continue

            host_baseline = self.baseline[hostid]
            if host == host_baseline:
                continue

            host_anomalies = {}
            if 'Files' in host:
                baseline_files = host_baseline.get('Files',[])
                anomalous_files = []
                for f in host['Files']:
                    if f not in baseline_files:
                        anomalous_files.append(f)
                if anomalous_files:
                    host_anomalies['Files'] = anomalous_files

            if 'Processes' in host:
                baseline_processes = host_baseline.get('Processes',[])
                anomalous_processes = []
                for p in host['Processes']:
                    if p not in baseline_processes:
                        anomalous_processes.append(p)
                if anomalous_processes:
                    host_anomalies['Processes'] = anomalous_processes

            if host_anomalies:
                anomaly_dict[hostid] = host_anomalies

        return anomaly_dict

    def red_add_ips(self, obs):
        for hostid in obs:
            if hostid == 'success':
                continue
            host = obs[hostid]
            for interface in host['Interface']:
                ip = interface['IP Address']
                subnet = interface['Subnet']
                if subnet not in self.red_known_subnets:
                    self.red_known_subnets.add(subnet)
                if str(ip) not in self.red_info:
                    subnet = self.red_get_subnet(ip)
                    hostname = self.red_generate_name('HOST')
                    self.red_info[str(ip)] = [subnet, str(ip), hostname, False, 'None']
                elif self.red_info[str(ip)][0].startswith('UNKNOWN_'):
                    self.red_info[str(ip)][0] = self.red_get_subnet(ip)

    def red_process_exploit(self, obs):
        for hostid in obs:
            if hostid == 'success':
                continue

            host = obs[hostid]
            if 'Sessions' in host:
                ip = str(host['Interface'][0]['IP Address'])
                hostname = host['System info']['Hostname']
                session = host['Sessions'][0]
                access = 'Privileged' if 'Username' in session and session['Username'] in ['root', 'SYSTEM'] else 'User'

                self.red_info[ip][2] = hostname
                self.red_info[ip][4] = access

    def red_process_priv_esc(self, obs, hostname):
        if obs['success'] == False:
            red_info = [info for info in self.red_info.values() if info[2] == hostname]
            if len(red_info) > 0:
                red_info[0][4] = 'None'
        else:
            for hostid in obs:
                if hostid == 'success':
                    continue
                host = obs[hostid]
                ip = host['Interface'][0]['IP Address']
    
                if 'Sessions' in host:
                    access = 'Privileged'
                    self.red_info[str(ip)][4] = access
                else:
                    subnet = self.red_get_subnet(ip)
                    hostname = self.red_generate_name('HOST')
    
                    if str(ip) not in self.red_info:
                        self.red_info[str(ip)] = [subnet, str(ip), hostname, False, 'None']
                    else:
                        self.red_info[str(ip)][0] = subnet
                        self.red_info[str(ip)][2] = hostname

    def red_create_red_table(self):
        # The table data is all stored inside the ip nodes
        # which form the rows of the table
        table = PrettyTable([
            'Subnet',
            'IP Address',
            'Hostname',
            'Scanned',
            'Access',
        ])
        for ip in self.red_info:
            table.add_row(self.red_info[ip])

        table.sortby = 'IP Address'
        table.success = self.red_last_action_success

        return table

    def blue_create_blue_table(self, success):
        table = PrettyTable([
            'Subnet',
            'IP Address',
            'Hostname',
            'Activity',
            'Compromised'
            ])
        for hostid in self.blue_info:
            table.add_row(self.blue_info[hostid])
        
        table.sortby = 'Hostname'
        table.success = success

        return table
    

    def blue_interpret_connections(self,activity:list):
        num_connections = len(activity)
        ports = set([item['Connections'][0]['local_port'] \
            for item in activity if 'Connections' in item and 'local_port' in item['Connections'][0]])
        port_focus = len(ports)

        remote_ports = set([item['Connections'][0].get('remote_port') \
            for item in activity if 'Connections' in item])
        if None in remote_ports:
            remote_ports.remove(None)

        if num_connections >= 3 and port_focus >=3:
            anomaly = 'Scan'
        elif 4444 in remote_ports:
            anomaly = 'Exploit'
        elif num_connections >= 3 and port_focus == 1:
            anomaly = 'Exploit'
        else:
            anomaly = 'Scan'

        return anomaly

    def red_get_subnet(self, ip):
        for subnet in self.red_known_subnets:
            if ip in subnet:
                return str(subnet)
        return self.red_generate_name('SUBNET')

    def red_generate_name(self, datatype: str):
        self.red_id_tracker += 1
        unique_id = 'UNKNOWN_' + datatype + ': ' + str(self.red_id_tracker)
        return unique_id
    
    def get_rewards(self):
            true_dict = self.get_true_dict()
            host_names =  list(true_dict.keys())
            red_rewards = 0
            high_value_targets = ['Enterprise0','Enterprise1','Enterprise2','Op_Server0']
        
        
            for host in host_names:
                if true_dict[host]['access'] == 'Privileged':
                    if host in high_value_targets:
                        red_rewards += 1
                    else:
                        red_rewards += 0.1
                        
            
                
            last_red_action = self.get_last_action('Red')
            last_blue_action = self.get_last_action('Blue')
            
            
            
            if isinstance(last_red_action, Impact) and last_red_action.hostname == 'Op_Server0':
                red_rewards += 10
                
            elif isinstance(last_blue_action, Restore):
                red_rewards += 1
                
            scaled_red_rewards = red_rewards * self.reward_scale_factor

            return scaled_red_rewards, (1-scaled_red_rewards)
       
    def get_true_dict(self):
        
        true_dict = {}
        
        true_obs = deepcopy(self.env.get_agent_state('True'))
        success = true_obs.pop('success')
               
        for hostid in true_obs:
            if '_router' in hostid or 'success' in hostid:
                continue
            host = true_obs[hostid]
            for interface in host['Interface']:
                ip = interface['IP Address']
                if str(ip) == '127.0.0.1':
                    continue
                if 'Subnet' not in interface:
                    continue
                subnet = interface['Subnet']
                hostname = host['System info']['Hostname']
                action_space = self.get_action_space(agent = 'Red')
                known = action_space['ip_address'][ip]
                scanned = True if str(ip) in self.scanned_ips else False
                access = self._determine_red_access(host['Sessions'])

                info = {'subnet':subnet, 'ip':ip, 'hostname':hostname, 'known':known, 'scanned':scanned, 'access':access}
                
                true_dict.update({hostname:info})
                
        return true_dict
    

    def red_action_to_int(self, action):
        return self.red_complete_action_space.index(action)
    
    def red_int_to_action(self, val:int):
        action = self.red_complete_action_space[val]
        
        return action
    
    def blue_int_to_action(self, val:int):
        
        action = self.blue_complete_action_space[val]
        
        return action
    
    def red_int_to_vector(self, val:int):
        
        vec = np.zeros(len(self.red_complete_action_space))
        
        vec[val] = 1
        
        return vec
    
    def blue_int_to_vector(self, val:int):
        
        vec = np.zeros(len(self.blue_complete_action_space))
        
        vec[val] = 1
        
        return vec
    
    def check_blue_action_validity(self, action):
        return action in self.blue_latest_avalibale_actions

    def check_red_action_validity(self, action):
         return action in self.red_latest_avalibale_actions

    def _update_scanned(self):
        
        action = self.get_last_action(agent='Red')
        if action.__class__.__name__ == 'DiscoverNetworkServices':
            red_obs = deepcopy(self.get_observation(agent='Red'))
            success = red_obs['success']
            if success:
                ip = red_obs.popitem()[0]
                self.scanned_ips.add(ip)

    def _determine_red_access(self,session_list):
        for session in session_list:
            if session['Agent'] != 'Red':
                continue
            privileged = session['Username'] in {'root','SYSTEM'}
            return 'Privileged' if privileged else 'User'

        return 'None'
    
    def red_action_space_change(self, action_space: dict) -> int:
        assert type(action_space) is dict, \
            f"Wrapper required a dictionary action space. " \
            f"Please check that the wrappers below the ReduceActionSpaceWrapper return the action space as a dict "
        possible_actions = []
        temp = {}
        params = ['action']

        for i, action in enumerate(action_space['action']):
            if action not in self.red_action_signature:
                self.red_action_signature[action] = inspect.signature(action).parameters
            param_dict = {}
            param_list = [{}]
            for p in self.red_action_signature[action]:
                if p == 'priority':
                    continue
                temp[p] = []
                if p not in params:
                    params.append(p)

                if len(action_space[p]) == 1:
                    for p_dict in param_list:
                        p_dict[p] = list(action_space[p].keys())[0]
                else:
                    new_param_list = []
                    for p_dict in param_list:
                        for key, val in action_space[p].items():
                            p_dict[p] = key
                            new_param_list.append({key: value for key, value in p_dict.items()})
                    param_list = new_param_list
            for p_dict in param_list:
                possible_actions.append(action(**p_dict))

        
        return possible_actions

    def blue_action_space_change(self, action_space: dict) -> int:
        assert type(action_space) is dict, \
            f"Wrapper required a dictionary action space. " \
            f"Please check that the wrappers below the ReduceActionSpaceWrapper return the action space as a dict "
        possible_actions = []
        temp = {}
        params = ['action']
        # for action in action_space['action']:
        for i, action in enumerate(action_space['action']):
            if action not in self.blue_action_signature:
                self.blue_action_signature[action] = inspect.signature(action).parameters
            param_dict = {}
            param_list = [{}]
            for p in self.blue_action_signature[action]:
                if p == 'priority':
                    continue
                temp[p] = []
                if p not in params:
                    params.append(p)

                if len(action_space[p]) == 1:
                    for p_dict in param_list:
                        p_dict[p] = list(action_space[p].keys())[0]
                else:
                    new_param_list = []
                    for p_dict in param_list:
                        for key, val in action_space[p].items():
                            p_dict[p] = key
                            new_param_list.append({key: value for key, value in p_dict.items()})
                    param_list = new_param_list
            for p_dict in param_list:
                possible_actions.append(action(**p_dict))

        
        return possible_actions

    def get_red_actions(self) -> list:
        return self.red_action_space_change(self.get_action_space('Red'))
    
    def get_blue_actions(self) -> list:
        return self.blue_action_space_change(self.get_action_space('Blue'))
    
    def get_last_action(self, agent):
        if agent == 'Red':
            return(self.red_actions_excuted[-1])
        elif agent == 'Blue':
            return(self.blue_actions_excuted[-1])
    
    def validity_of_action_checking(self, agent, action):

        # if agent == 'Red':
        #     action_space = self.red

        # Just get this stuff directly from the enviroment controler

        action_space = self.env.environment_controller.agent_interfaces[
                                 agent].action_space.get_action_space()

        # checks if the action is within the action space (Not needed as the int to action will shit the bed anyway)
        if type(action) not in action_space['action']:
            message = f'Action {action} not in action space for agent {agent}.'
            return InvalidAction(action=action, error=message)

        # Checks if it is acessing somthing it cant yet
        if not action_space['action'][type(action)]:
            message = f'Action {action} is not valid for agent {agent} at the moment. This usually means it is trying to access a host it has not discovered yet.'
            return InvalidAction(action=action, error=message)

        # next for each parameter in the action
        for parameter_name, parameter_value in action.get_params().items():
            if parameter_name not in action_space:
                continue

            if parameter_value not in action_space[parameter_name]:
                message = f'Action {action} has parameter {parameter_name} valued at {parameter_value}. However, {parameter_value} is not in the action space for agent {agent}.'
                return InvalidAction(action=action, error=message)

            if not action_space[parameter_name][parameter_value]:
                message = f'Action {action} has parameter {parameter_name} valued at the invalid value of {parameter_value}. This usually means an agent is trying to utilise information it has not discovered yet such as an ip_address or port number.'
                return InvalidAction(action=action, error=message)
        
        return action

    def get_action_mask(self, agent):

        mask = {}
        if agent == 'Red':
            full_acsp = deepcopy(self.red_complete_action_space)
        else:
            full_acsp = deepcopy(self.blue_complete_action_space)

        for i, action in enumerate(full_acsp):
            checked_action = self.validity_of_action_checking(agent, action)
            if isinstance(checked_action, InvalidAction):
                mask[i] = 0
            else:
                mask[i] = 1

        return(mask)
    
  

            
if __name__ == '__main__':
    print('all tests passed')


