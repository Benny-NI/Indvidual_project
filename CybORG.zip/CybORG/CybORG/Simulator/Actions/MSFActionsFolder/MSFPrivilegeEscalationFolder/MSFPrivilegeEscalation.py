# Copyright DST Group. Licensed under the MIT license.
from CybORG.Simulator.Actions.MSFActionsFolder import MSFAction


class MSFPrivilegeEscalation(MSFAction):
    def __init__(self):
        super().__init__()

    def execute(self, state):
        pass
