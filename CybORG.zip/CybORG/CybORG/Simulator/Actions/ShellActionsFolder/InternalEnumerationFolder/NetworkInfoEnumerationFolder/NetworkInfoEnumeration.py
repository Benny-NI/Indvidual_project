# Copyright DST Group. Licensed under the MIT license.
from CybORG.Simulator.Actions.ShellActionsFolder.InternalEnumerationFolder.InternalEnumeration import InternalEnumeration


class NetworkInfoEnumeration(InternalEnumeration):
    def __init__(self):
        super().__init__()

    def execute(self):
        pass
