from .NetworkInfoEnumerationFolder import IPConfig, IFConfig
from .HostInfoEnumerationFolder import SystemInfo, Uname