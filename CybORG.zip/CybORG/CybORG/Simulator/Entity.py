# Copyright DST Group. Licensed under the MIT license.


class Entity:
    def __init__(self):
        pass

    def get_state(self):
        pass
