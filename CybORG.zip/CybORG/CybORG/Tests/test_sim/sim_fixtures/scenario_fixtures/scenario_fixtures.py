from .scenario1b import scenario1b
from .scenario2 import scenario2

SCENARIOS = {
        'Scenario1b': scenario1b,
        'Scenario2': scenario2,
        }
